# ProGuard Rules for PDF & Image Converter
-keepclassmembers class * extends androidx.lifecycle.ViewModel { *; }

# PDFBox Android rules
-keep class com.tom_roush.pdfbox.** { *; }
-dontwarn com.tom_roush.pdfbox.**

# AdMob & Play Services rules
-keep public class com.google.android.gms.ads.** { public *; }
-keep public class com.google.ads.** { public *; }
-dontwarn com.google.android.gms.ads.**
