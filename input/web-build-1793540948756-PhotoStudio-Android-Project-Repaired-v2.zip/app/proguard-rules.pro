# Project-specific R8 rules can be added here.
# Keep existing application and AdMob behavior; no broad keep rules are added.
