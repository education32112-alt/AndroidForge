package com.educationwithhassan.pdfimageconverter.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.educationwithhassan.pdfimageconverter.engine.StorageManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(navController: NavController) {
    val context = LocalContext.current
    val dir = remember { StorageManager.getOutputDirectory(context) }
    val files = remember { dir.listFiles()?.toList() ?: emptyList() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Recent Conversions", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (files.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("No converted files found yet.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(files) { file ->
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Description, contentDescription = null)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = file.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(text = "${file.length() / 1024} KB", fontSize = 11.sp)
                            }
                            TextButton(onClick = { StorageManager.shareFile(context, file) }) {
                                Text("Share")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ListItem(
                headlineContent = { Text("Privacy Policy") },
                supportingContent = { Text("Offline document processing policy & AdMob disclosure") },
                modifier = Modifier.fillMaxWidth(),
                trailingContent = {
                    Button(onClick = { navController.navigate("privacy_policy") }) { Text("View") }
                }
            )
            Divider()
            ListItem(
                headlineContent = { Text("Terms of Use") },
                modifier = Modifier.fillMaxWidth(),
                trailingContent = {
                    Button(onClick = { navController.navigate("terms_of_use") }) { Text("View") }
                }
            )
            Divider()
            ListItem(
                headlineContent = { Text("About Application") },
                supportingContent = { Text("Publisher: Rana Hassan · Version 1.0.0") },
                modifier = Modifier.fillMaxWidth(),
                trailingContent = {
                    Button(onClick = { navController.navigate("about") }) { Text("About") }
                }
            )
            Divider()
            ListItem(
                headlineContent = { Text("Help & FAQ") },
                modifier = Modifier.fillMaxWidth(),
                trailingContent = {
                    Button(onClick = { navController.navigate("faq") }) { Text("FAQ") }
                }
            )
        }
    }
}
