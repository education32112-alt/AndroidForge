package com.educationwithhassan.pdfimageconverter.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.educationwithhassan.pdfimageconverter.engine.ImageEngine
import com.educationwithhassan.pdfimageconverter.engine.StorageManager
import com.educationwithhassan.pdfimageconverter.ui.theme.RoyalBlue
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageConverterScreen(navController: NavController) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var targetFormat by remember { mutableStateOf("PNG") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { selectedUri = it }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Image Format Converter", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = { picker.launch("image/*") },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Icon(imageVector = Icons.Default.UploadFile, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = if (selectedUri != null) "Image Selected" else "Select Image")
            }

            Text("Select Output Format:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("PNG", "JPEG", "WEBP").forEach { fmt ->
                    FilterChip(
                        selected = targetFormat == fmt,
                        onClick = { targetFormat = fmt },
                        label = { Text(fmt) }
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    coroutineScope.launch {
                        val compressFmt = when (targetFormat) {
                            "JPEG" -> Bitmap.CompressFormat.JPEG
                            "WEBP" -> Bitmap.CompressFormat.WEBP
                            else -> Bitmap.CompressFormat.PNG
                        }
                        val ext = targetFormat.lowercase()
                        val outFile = StorageManager.generateUniqueFile(context, "Converted", ext)
                        val res = ImageEngine.processImage(context, uri, outFile, compressFmt, 90)
                        res.onSuccess {
                            Toast.makeText(context, "Saved to: ${outFile.name}", Toast.LENGTH_SHORT).show()
                            StorageManager.shareFile(context, outFile, "image/$ext")
                        }.onFailure { err ->
                            Toast.makeText(context, "Error: ${err.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                enabled = selectedUri != null,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text("Convert Image", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageResizerScreen(navController: NavController) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var widthInput by remember { mutableStateOf("800") }
    var heightInput by remember { mutableStateOf("600") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { selectedUri = it }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Image Resizer", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = { picker.launch("image/*") },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text("Select Image to Resize")
            }

            OutlinedTextField(
                value = widthInput,
                onValueChange = { widthInput = it },
                label = { Text("Target Width (px)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = heightInput,
                onValueChange = { heightInput = it },
                label = { Text("Target Height (px)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    val w = widthInput.toIntOrNull() ?: 800
                    val h = heightInput.toIntOrNull() ?: 600
                    coroutineScope.launch {
                        val outFile = StorageManager.generateUniqueFile(context, "Resized", "jpg")
                        val res = ImageEngine.processImage(context, uri, outFile, Bitmap.CompressFormat.JPEG, 90, w, h)
                        res.onSuccess {
                            Toast.makeText(context, "Resized to ${w}x${h} successfully!", Toast.LENGTH_SHORT).show()
                            StorageManager.shareFile(context, outFile, "image/jpeg")
                        }.onFailure { err ->
                            Toast.makeText(context, "Resize error: ${err.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                enabled = selectedUri != null,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text("Resize and Save", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageCompressorScreen(navController: NavController) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var quality by remember { mutableFloatStateOf(65f) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { selectedUri = it }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Image Compressor", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = { picker.launch("image/*") },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text("Select Image to Compress")
            }

            Text("Compression Quality: ${quality.toInt()}%", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Slider(
                value = quality,
                onValueChange = { quality = it },
                valueRange = 10f..95f,
                steps = 17
            )

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    coroutineScope.launch {
                        val outFile = StorageManager.generateUniqueFile(context, "Compressed", "jpg")
                        val res = ImageEngine.processImage(context, uri, outFile, Bitmap.CompressFormat.JPEG, quality.toInt())
                        res.onSuccess {
                            Toast.makeText(context, "Compressed successfully! Saved to ${outFile.name}", Toast.LENGTH_SHORT).show()
                            StorageManager.shareFile(context, outFile, "image/jpeg")
                        }.onFailure { err ->
                            Toast.makeText(context, "Compress error: ${err.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                enabled = selectedUri != null,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text("Compress Image", fontWeight = FontWeight.Bold)
            }
        }
    }
}
