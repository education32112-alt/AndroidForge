package com.educationwithhassan.pdfimageconverter.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object ImageEngine {

    suspend fun processImage(
        context: Context,
        inputUri: Uri,
        outputFile: File,
        format: Bitmap.CompressFormat, // JPEG, PNG, WEBP
        quality: Int, // 10 to 100
        targetWidth: Int? = null,
        targetHeight: Int? = null
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            // 1. Measure dimensions first
            val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(inputUri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, boundsOptions)
            }

            val origWidth = boundsOptions.outWidth
            val origHeight = boundsOptions.outHeight
            if (origWidth <= 0 || origHeight <= 0) {
                return@withContext Result.failure(IllegalArgumentException("Unsupported image format."))
            }

            // 2. Downsample if needed
            val reqW = targetWidth ?: origWidth
            val reqH = targetHeight ?: origHeight

            var sampleSize = 1
            while ((origWidth / (sampleSize * 2)) >= reqW && (origHeight / (sampleSize * 2)) >= reqH) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            val decodedBitmap = context.contentResolver.openInputStream(inputUri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOptions)
            } ?: return@withContext Result.failure(IllegalStateException("Failed to decode image."))

            // 3. Precise scale if target requested
            val finalBitmap = if (targetWidth != null && targetHeight != null &&
                (decodedBitmap.width != targetWidth || decodedBitmap.height != targetHeight)) {
                Bitmap.createScaledBitmap(decodedBitmap, targetWidth, targetHeight, true)
            } else {
                decodedBitmap
            }

            FileOutputStream(outputFile).use { outStream ->
                finalBitmap.compress(format, quality.coerceIn(10, 100), outStream)
                outStream.flush()
            }

            if (finalBitmap != decodedBitmap) {
                finalBitmap.recycle()
            }
            decodedBitmap.recycle()

            Result.success(outputFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
