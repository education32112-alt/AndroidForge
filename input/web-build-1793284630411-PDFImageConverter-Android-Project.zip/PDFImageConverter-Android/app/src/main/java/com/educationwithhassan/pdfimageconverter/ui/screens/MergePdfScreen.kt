package com.educationwithhassan.pdfimageconverter.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.educationwithhassan.pdfimageconverter.engine.PdfEngine
import com.educationwithhassan.pdfimageconverter.engine.StorageManager
import com.educationwithhassan.pdfimageconverter.ui.theme.RoyalBlue
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MergePdfScreen(navController: NavController) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var isProcessing by remember { mutableStateOf(false) }

    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        selectedUris = selectedUris + uris
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Merge PDF Documents", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Button(
                onClick = { pickerLauncher.launch("application/pdf") },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Select PDF Files (${selectedUris.size} selected)")
            }

            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(selectedUris) { index, uri ->
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Doc ${index + 1}: ${uri.lastPathSegment ?: "file.pdf"}", fontSize = 12.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = { selectedUris = selectedUris.filterIndexed { i, _ -> i != index } }) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = Color.Red)
                            }
                        }
                    }
                }
            }

            Button(
                onClick = {
                    if (selectedUris.size < 2) {
                        Toast.makeText(context, "Please select at least 2 PDF files to merge", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    isProcessing = true
                    coroutineScope.launch {
                        // Copy uris to temp files
                        val tempFiles = selectedUris.mapIndexed { idx, uri ->
                            val tmp = File(context.cacheDir, "merge_input_$idx.pdf")
                            context.contentResolver.openInputStream(uri)?.use { input ->
                                FileOutputStream(tmp).use { output -> input.copyTo(output) }
                            }
                            tmp
                        }
                        val outFile = StorageManager.generateUniqueFile(context, "MergedDoc", "pdf")
                        val result = PdfEngine.mergePdfs(tempFiles, outFile) { _, _ -> }
                        isProcessing = false
                        result.onSuccess {
                            Toast.makeText(context, "Merged successfully!", Toast.LENGTH_SHORT).show()
                            StorageManager.shareFile(context, outFile)
                        }.onFailure { err ->
                            Toast.makeText(context, "Merge error: ${err.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                enabled = !isProcessing && selectedUris.size >= 2,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text(text = "Merge Documents", fontWeight = FontWeight.Bold)
            }
        }
    }
}
