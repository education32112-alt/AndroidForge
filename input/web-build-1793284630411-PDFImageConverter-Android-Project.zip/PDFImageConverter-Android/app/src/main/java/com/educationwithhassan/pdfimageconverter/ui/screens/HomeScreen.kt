package com.educationwithhassan.pdfimageconverter.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.educationwithhassan.pdfimageconverter.ui.theme.CyanAccent
import com.educationwithhassan.pdfimageconverter.ui.theme.Navy
import com.educationwithhassan.pdfimageconverter.ui.theme.RoyalBlue

@Composable
fun HomeScreen(navController: NavController) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Bar Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "PDF & Image Converter", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(text = "Convert, compress, and manage your documents.", fontSize = 11.sp, color = Color.Gray)
            }
            IconButton(onClick = { navController.navigate("settings") }) {
                Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings")
            }
        }

        // Hero Primary Card: Images to PDF
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { navController.navigate("images_to_pdf") },
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Navy)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        brush = Brush.horizontalGradient(
                            colors = listOf(Navy, RoyalBlue, CyanAccent)
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "PRIMARY TOOL",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Images to PDF", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text(text = "Select multiple photos and combine them into a single PDF.", fontSize = 12.sp, color = Color.White.copy(alpha = 0.85f))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "Convert Images →", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyanAccent)
                }
            }
        }

        // Quick Tools Grid
        Text(text = "DOCUMENT & IMAGE TOOLS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ToolCard(Modifier.weight(1f), "PDF Viewer", "Inspect documents", Icons.Default.PictureAsPdf, Color(0xFF2563EB)) {
                navController.navigate("pdf_viewer")
            }
            ToolCard(Modifier.weight(1f), "Merge PDF", "Combine files", Icons.Default.CallMerge, Color(0xFF4F46E5)) {
                navController.navigate("merge_pdf")
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ToolCard(Modifier.weight(1f), "Split PDF", "Extract pages", Icons.Default.CallSplit, Color(0xFF06B6D4)) {
                navController.navigate("split_pdf")
            }
            ToolCard(Modifier.weight(1f), "Format Convert", "JPG, PNG, WebP", Icons.Default.SwapHoriz, Color(0xFF10B981)) {
                navController.navigate("image_converter")
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ToolCard(Modifier.weight(1f), "Resize Image", "Custom dimensions", Icons.Default.AspectRatio, Color(0xFFF59E0B)) {
                navController.navigate("image_resizer")
            }
            ToolCard(Modifier.weight(1f), "Compress Image", "Reduce file size", Icons.Default.Compress, Color(0xFFEF4444)) {
                navController.navigate("image_compressor")
            }
        }

        // Bottom Navigation Bar Shortcuts
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            TextButton(onClick = { navController.navigate("history") }) {
                Icon(imageVector = Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "History")
            }
            TextButton(onClick = { navController.navigate("faq") }) {
                Icon(imageVector = Icons.Default.HelpOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Help")
            }
            TextButton(onClick = { navController.navigate("privacy_policy") }) {
                Icon(imageVector = Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Privacy")
            }
        }
    }
}

@Composable
private fun ToolCard(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Surface(
                modifier = Modifier.size(40.dp),
                shape = RoundedCornerShape(12.dp),
                color = iconTint.copy(alpha = 0.12f)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(text = subtitle, fontSize = 10.sp, color = Color.Gray)
        }
    }
}
