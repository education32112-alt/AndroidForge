package com.educationwithhassan.pdfimageconverter.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.educationwithhassan.pdfimageconverter.engine.PdfEngine
import com.educationwithhassan.pdfimageconverter.engine.StorageManager
import com.educationwithhassan.pdfimageconverter.ui.theme.RoyalBlue
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SplitPdfScreen(navController: NavController) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var pageInput by remember { mutableStateOf("1") }
    var isProcessing by remember { mutableStateOf(false) }

    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri -> selectedUri = uri }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Split PDF Document", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = { pickerLauncher.launch("application/pdf") },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Icon(imageVector = Icons.Default.UploadFile, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = if (selectedUri != null) "File Selected" else "Select PDF to Split")
            }

            OutlinedTextField(
                value = pageInput,
                onValueChange = { pageInput = it },
                label = { Text("Pages to extract (e.g. 1, 2, 3)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    val uri = selectedUri ?: return@Button
                    val pages = pageInput.split(",")
                        .mapNotNull { it.trim().toIntOrNull() }
                    if (pages.isEmpty()) {
                        Toast.makeText(context, "Enter valid page numbers", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    isProcessing = true
                    coroutineScope.launch {
                        val tmp = File(context.cacheDir, "split_source.pdf")
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            FileOutputStream(tmp).use { output -> input.copyTo(output) }
                        }
                        val outFile = StorageManager.generateUniqueFile(context, "SplitDoc", "pdf")
                        val result = PdfEngine.splitPdf(tmp, pages, outFile) { _, _ -> }
                        isProcessing = false
                        result.onSuccess {
                            Toast.makeText(context, "Split PDF Created!", Toast.LENGTH_SHORT).show()
                            StorageManager.shareFile(context, outFile)
                        }.onFailure { err ->
                            Toast.makeText(context, "Error: ${err.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                enabled = !isProcessing && selectedUri != null,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue)
            ) {
                Text(text = "Extract Selected Pages", fontWeight = FontWeight.Bold)
            }
        }
    }
}
