package com.educationwithhassan.pdfimageconverter.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyPolicyScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Privacy Policy", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Privacy Policy", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Effective Date: October 2026 · Version 1.0.0", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(6.dp))
            Text("1. Document Processing", fontWeight = FontWeight.Bold)
            Text("PDF & Image Converter executes all conversions entirely on your device. Selected documents, photos, and generated PDFs never leave your device memory or local storage sandbox.")
            Spacer(modifier = Modifier.height(6.dp))
            Text("2. Advertising and Analytics", fontWeight = FontWeight.Bold)
            Text("This app integrates Google AdMob SDK. Google AdMob may collect device identifiers and usage telemetry strictly for advertising delivery and fraud detection in accordance with Google Privacy Policy.")
            Spacer(modifier = Modifier.height(6.dp))
            Text("3. Storage Permissions", fontWeight = FontWeight.Bold)
            Text("The app uses standard Storage Access Framework and Scoped Storage. No broad file system access is requested.")
            Spacer(modifier = Modifier.height(6.dp))
            Text("Contact: support@educationwithhassan.com")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TermsOfUseScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Terms of Use", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Terms of Service", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("By using this application, you agree to convert only documents for which you hold appropriate rights. The software is provided AS IS without warranties of any kind.")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("PDF & Image Converter", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Version 1.0.0 (Release 1)", fontSize = 12.sp)
            Text("Publisher: Rana Hassan", fontSize = 13.sp)
            Text("Package: com.educationwithhassan.pdfimageconverter", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            Text("Target Platforms: Android Phones, Tablets, and Amazon Fire OS Devices", fontSize = 12.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactUsScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Contact Us", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Support Channel", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("For support inquiries, bug reports, and assistance:")
            Text("Email: support@educationwithhassan.com", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LicensesScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Open Source Licenses", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Open Source Licenses", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("• PDFBox-Android (Apache License 2.0)")
            Text("• Jetpack Compose & Material 3 (Apache License 2.0)")
            Text("• AndroidX Core, Lifecycle, Activity (Apache License 2.0)")
            Text("• Kotlin Coroutines (Apache License 2.0)")
            Text("• Google Mobile Ads SDK (Google Play Services Terms)")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FaqScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Help & FAQ", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Q: How do I convert images to PDF?", fontWeight = FontWeight.Bold)
            Text("A: Tap 'Images to PDF', select pictures from your gallery, choose A4 or Letter, and tap Convert.")
            Divider()
            Text("Q: Does it work offline on Amazon Fire tablets?", fontWeight = FontWeight.Bold)
            Text("A: Yes! All conversion tasks run completely on-device without needing internet connection.")
            Divider()
            Text("Q: How do I merge PDFs?", fontWeight = FontWeight.Bold)
            Text("A: Open 'Merge PDF', pick 2 or more files, and tap 'Merge Documents'.")
        }
    }
}
