package com.educationwithhassan.pdfimageconverter.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfDocument
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import com.tomroush.pdfbox.multipdf.PDFMergerUtility
import com.tomroush.pdfbox.pdmodel.PDDocument

object PdfEngine {

    /**
     * Converts a list of image URIs to a single multi-page PDF document
     * Protects against OutOfMemoryError by calculating inSampleSize for high-res images
     */
    suspend fun convertImagesToPdf(
        context: Context,
        imageUris: List<Uri>,
        outputFile: File,
        pageSize: String = "A4", // A4, Letter, Fit
        marginDp: Int = 18,
        onProgress: (Int, String) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        val pdfDocument = PdfDocument()
        try {
            val total = imageUris.size
            if (total == 0) {
                return@withContext Result.failure(IllegalArgumentException("No images provided for PDF conversion."))
            }

            imageUris.forEachIndexed { index, uri ->
                onProgress((((index + 0.1f) / total) * 90).toInt(), "Processing image ${index + 1} of $total...")

                // 1. Measure dimensions without full decode to avoid memory spike
                val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, boundsOptions)
                }

                val origWidth = boundsOptions.outWidth
                val origHeight = boundsOptions.outHeight

                if (origWidth <= 0 || origHeight <= 0) {
                    throw IllegalArgumentException("Cannot decode image stream at index $index")
                }

                // 2. Compute sample size (target max dimension 2400px for print quality without OOM)
                val maxTargetDim = 2400
                var sampleSize = 1
                while ((origWidth / sampleSize) > maxTargetDim || (origHeight / sampleSize) > maxTargetDim) {
                    sampleSize *= 2
                }

                val decodeOptions = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = Bitmap.Config.RGB_565 // 50% memory savings vs ARGB_8888
                }

                val bitmap: Bitmap? = context.contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream, null, decodeOptions)
                }

                if (bitmap == null) {
                    throw IllegalStateException("Failed to decode image bitmap at page ${index + 1}")
                }

                try {
                    // Standard print dimensions in points (72 points = 1 inch)
                    val (pageWidth, pageHeight) = when (pageSize.uppercase()) {
                        "LETTER" -> 612 to 792
                        "FIT" -> bitmap.width to bitmap.height
                        else -> 595 to 842 // Standard A4
                    }

                    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, index + 1).create()
                    val page = pdfDocument.startPage(pageInfo)
                    val canvas: Canvas = page.canvas

                    canvas.drawColor(Color.WHITE)

                    val availableWidth = (pageWidth - marginDp * 2).toFloat()
                    val availableHeight = (pageHeight - marginDp * 2).toFloat()
                    val scale = Math.min(availableWidth / bitmap.width, availableHeight / bitmap.height)

                    val scaledWidth = bitmap.width * scale
                    val scaledHeight = bitmap.height * scale
                    val left = marginDp + (availableWidth - scaledWidth) / 2
                    val top = marginDp + (availableHeight - scaledHeight) / 2

                    val destRect = android.graphics.RectF(left, top, left + scaledWidth, top + scaledHeight)
                    canvas.drawBitmap(bitmap, null, destRect, null)

                    pdfDocument.finishPage(page)
                } finally {
                    bitmap.recycle()
                }
            }

            onProgress(95, "Finalizing PDF file...")
            FileOutputStream(outputFile).use { outStream ->
                pdfDocument.writeTo(outStream)
                outStream.flush()
            }

            onProgress(100, "Conversion complete!")
            Result.success(outputFile)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            pdfDocument.close()
        }
    }

    /**
     * Merges multiple PDF files into one output file using PDFBox-Android
     */
    suspend fun mergePdfs(
        pdfFiles: List<File>,
        outputFile: File,
        onProgress: (Int, String) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            if (pdfFiles.size < 2) {
                return@withContext Result.failure(IllegalArgumentException("At least 2 PDF documents are required to merge."))
            }

            onProgress(20, "Initializing PDF merger...")
            val merger = PDFMergerUtility().apply {
                destinationFileName = outputFile.absolutePath
            }

            pdfFiles.forEachIndexed { idx, file ->
                onProgress(30 + ((idx / pdfFiles.size.toFloat()) * 50).toInt(), "Merging ${file.name}...")
                merger.addSource(file)
            }

            onProgress(85, "Writing unified PDF stream...")
            merger.mergeDocuments(null)

            onProgress(100, "Merge complete!")
            Result.success(outputFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Splits a PDF and extracts selected pages into a new document
     */
    suspend fun splitPdf(
        sourceFile: File,
        pagesToExtract: List<Int>, // 1-based indices
        outputFile: File,
        onProgress: (Int, String) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            onProgress(20, "Loading source document...")
            PDDocument.load(sourceFile).use { donorDoc ->
                val totalPages = donorDoc.numberOfPages
                val validPages = pagesToExtract.filter { it in 1..totalPages }.distinct().sorted()

                if (validPages.isEmpty()) {
                    return@withContext Result.failure(IllegalArgumentException("No valid pages selected within document range (1..$totalPages)."))
                }

                onProgress(50, "Extracting ${validPages.size} pages...")
                PDDocument().use { newDoc ->
                    validPages.forEach { pageNum ->
                        newDoc.addPage(donorDoc.getPage(pageNum - 1))
                    }

                    onProgress(85, "Saving output PDF...")
                    newDoc.save(outputFile)
                }
            }

            onProgress(100, "Extraction complete!")
            Result.success(outputFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
