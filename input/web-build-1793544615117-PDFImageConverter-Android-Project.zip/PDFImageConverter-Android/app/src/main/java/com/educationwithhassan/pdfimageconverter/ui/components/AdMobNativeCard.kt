package com.educationwithhassan.pdfimageconverter.ui.components

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.educationwithhassan.pdfimageconverter.admob.AdMobManager
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView

/**
 * AdMobNativeCard
 * Production-ready Jetpack Compose native ad container.
 * Loads AdMob Native Advanced Ad (ID: ca-app-pub-3133971041724338/9979879405).
 */
@Composable
fun AdMobNativeCard(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var nativeAd by remember { mutableStateOf<NativeAd?>(null) }

    DisposableEffect(context) {
        var isDisposed = false
        val adLoader = AdLoader.Builder(context, AdMobManager.nativeAdUnitId)
            .forNativeAd { ad ->
                if (!isDisposed) {
                    nativeAd?.destroy()
                    nativeAd = ad
                    Log.d("AdMobNativeCard", "Native ad loaded successfully: \${ad.headline}")
                } else {
                    ad.destroy()
                }
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w("AdMobNativeCard", "Native ad failed to load: \${error.message} (code: \${error.code})")
                }
            })
            .withNativeAdOptions(
                NativeAdOptions.Builder()
                    .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
                    .build()
            )
            .build()

        adLoader.loadAd(AdRequest.Builder().build())

        onDispose {
            isDisposed = true
            nativeAd?.destroy()
        }
    }

    nativeAd?.let { ad ->
        Card(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            ),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                factory = { ctx ->
                    createNativeAdView(ctx, ad)
                },
                update = { view ->
                    populateNativeAdView(ad, view)
                }
            )
        }
    }
}

private fun createNativeAdView(context: Context, ad: NativeAd): NativeAdView {
    val nativeAdView = NativeAdView(context).apply {
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    val rootLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    val topRow = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
    }

    val badge = TextView(context).apply {
        text = "Ad"
        textSize = 10f
        setTypeface(null, Typeface.BOLD)
        setTextColor(AndroidColor.parseColor("#FFFFFF"))
        val shape = GradientDrawable().apply {
            setColor(AndroidColor.parseColor("#2563EB"))
            cornerRadius = dpToPx(context, 4).toFloat()
        }
        background = shape
        val hPad = dpToPx(context, 5)
        val vPad = dpToPx(context, 2)
        setPadding(hPad, vPad, hPad, vPad)
    }

    val iconView = ImageView(context).apply {
        layoutParams = LinearLayout.LayoutParams(
            dpToPx(context, 36),
            dpToPx(context, 36)
        ).apply {
            marginStart = dpToPx(context, 8)
        }
    }

    val headlineView = TextView(context).apply {
        textSize = 14f
        setTypeface(null, Typeface.BOLD)
        setTextColor(AndroidColor.parseColor("#0F172A"))
        layoutParams = LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            1f
        ).apply {
            marginStart = dpToPx(context, 8)
        }
        maxLines = 1
    }

    topRow.addView(badge)
    topRow.addView(iconView)
    topRow.addView(headlineView)
    rootLayout.addView(topRow)

    val bodyView = TextView(context).apply {
        textSize = 12f
        setTextColor(AndroidColor.parseColor("#475569"))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dpToPx(context, 6)
            bottomMargin = dpToPx(context, 8)
        }
        maxLines = 2
    }
    rootLayout.addView(bodyView)

    val ctaButton = Button(context).apply {
        textSize = 12f
        setTypeface(null, Typeface.BOLD)
        setTextColor(AndroidColor.WHITE)
        val ctaShape = GradientDrawable().apply {
            setColor(AndroidColor.parseColor("#2563EB"))
            cornerRadius = dpToPx(context, 8).toFloat()
        }
        background = ctaShape
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dpToPx(context, 40)
        )
    }
    rootLayout.addView(ctaButton)

    nativeAdView.addView(rootLayout)

    nativeAdView.headlineView = headlineView
    nativeAdView.bodyView = bodyView
    nativeAdView.iconView = iconView
    nativeAdView.callToActionView = ctaButton

    populateNativeAdView(ad, nativeAdView)
    return nativeAdView
}

private fun populateNativeAdView(ad: NativeAd, view: NativeAdView) {
    (view.headlineView as? TextView)?.text = ad.headline

    if (ad.body != null) {
        view.bodyView?.visibility = android.view.View.VISIBLE
        (view.bodyView as? TextView)?.text = ad.body
    } else {
        view.bodyView?.visibility = android.view.View.GONE
    }

    if (ad.callToAction != null) {
        view.callToActionView?.visibility = android.view.View.VISIBLE
        (view.callToActionView as? Button)?.text = ad.callToAction
    } else {
        view.callToActionView?.visibility = android.view.View.GONE
    }

    if (ad.icon != null) {
        view.iconView?.visibility = android.view.View.VISIBLE
        (view.iconView as? ImageView)?.setImageDrawable(ad.icon?.drawable)
    } else {
        view.iconView?.visibility = android.view.View.GONE
    }

    view.setNativeAd(ad)
}

private fun dpToPx(context: Context, dp: Int): Int {
    return TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        dp.toFloat(),
        context.resources.displayMetrics
    ).toInt()
}
