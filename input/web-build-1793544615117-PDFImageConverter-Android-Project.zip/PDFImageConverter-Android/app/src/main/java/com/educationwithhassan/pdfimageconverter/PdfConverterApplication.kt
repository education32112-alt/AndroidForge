package com.educationwithhassan.pdfimageconverter

import android.app.Application
import com.educationwithhassan.pdfimageconverter.admob.AppOpenAdManager
import com.educationwithhassan.pdfimageconverter.admob.InterstitialAdManager
import com.educationwithhassan.pdfimageconverter.admob.RewardedAdManager
import com.google.android.gms.ads.MobileAds
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class PdfConverterApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        
        // Initialize PDFBox Android resources for offline document rendering
        try {
            PDFBoxResourceLoader.init(applicationContext)
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        // Initialize Google Mobile Ads and centralized AdMob managers
        try {
            MobileAds.initialize(this) {
                AppOpenAdManager.init(this)
                InterstitialAdManager.initialize(this)
                RewardedAdManager.initialize(this)
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}
