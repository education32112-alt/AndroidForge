package com.educationwithhassan.pdfimageconverter.admob

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import java.util.Date

/**
 * AppOpenAdManager
 * Centralized manager for AdMob App Open Ads (ID: ca-app-pub-3133971041724338/5038543915).
 */
class AppOpenAdManager private constructor(private val application: Application) :
    Application.ActivityLifecycleCallbacks, DefaultLifecycleObserver {

    companion object {
        private const val TAG = "AppOpenAdManager"

        @Volatile
        var instance: AppOpenAdManager? = null
            private set

        fun init(app: Application): AppOpenAdManager {
            return instance ?: synchronized(this) {
                instance ?: AppOpenAdManager(app).also { instance = it }
            }
        }
    }

    private var appOpenAd: AppOpenAd? = null
    private var isLoadingAd = false
    var isShowingAd = false
    private var currentActivity: Activity? = null
    private var loadTime: Long = 0

    init {
        application.registerActivityLifecycleCallbacks(this)
        try {
            ProcessLifecycleOwner.get().lifecycle.addObserver(this)
        } catch (e: Throwable) {
            Log.w(TAG, "ProcessLifecycleOwner registration notice: ${e.message}")
        }
        loadAd()
    }

    private fun isAdAvailable(): Boolean {
        val wasLoadedRecently = (Date().time - loadTime) < (4 * 3600 * 1000)
        return appOpenAd != null && wasLoadedRecently
    }

    fun loadAd() {
        if (isLoadingAd || isAdAvailable()) return
        isLoadingAd = true
        Log.d(TAG, "Loading App Open Ad with Unit: ${AdMobManager.appOpenAdUnitId}")

        try {
            val request = AdRequest.Builder().build()
            AppOpenAd.load(
                application,
                AdMobManager.appOpenAdUnitId,
                request,
                object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(ad: AppOpenAd) {
                        Log.d(TAG, "App Open Ad loaded successfully.")
                        appOpenAd = ad
                        isLoadingAd = false
                        loadTime = Date().time
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        Log.w(TAG, "App Open Ad failed to load: ${loadAdError.message} (code: ${loadAdError.code})")
                        isLoadingAd = false
                        appOpenAd = null
                    }
                }
            )
        } catch (e: Throwable) {
            Log.e(TAG, "Exception during App Open ad load: ${e.message}")
            isLoadingAd = false
        }
    }

    fun showAdIfAvailable(activity: Activity, onShowComplete: () -> Unit = {}) {
        if (isShowingAd) {
            Log.d(TAG, "App Open Ad already showing.")
            onShowComplete()
            return
        }

        if (AdMobManager.isConversionActive) {
            Log.d(TAG, "Conversion active. Suppressing App Open ad.")
            onShowComplete()
            return
        }

        if (!isAdAvailable()) {
            Log.d(TAG, "App Open Ad not ready. Preloading for next session.")
            loadAd()
            onShowComplete()
            return
        }

        val ad = appOpenAd ?: run {
            onShowComplete()
            return
        }

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "App Open Ad dismissed.")
                appOpenAd = null
                isShowingAd = false
                loadAd()
                onShowComplete()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.w(TAG, "App Open Ad failed to show: ${adError.message}")
                appOpenAd = null
                isShowingAd = false
                loadAd()
                onShowComplete()
            }

            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "App Open Ad displayed.")
                isShowingAd = true
            }
        }

        isShowingAd = true
        try {
            ad.show(activity)
        } catch (e: Throwable) {
            Log.e(TAG, "Error showing App Open Ad: ${e.message}")
            isShowingAd = false
            onShowComplete()
        }
    }

    override fun onStart(owner: LifecycleOwner) {
        super.onStart(owner)
        currentActivity?.let { act ->
            showAdIfAvailable(act)
        }
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityStarted(activity: Activity) {
        currentActivity = activity
    }
    override fun onActivityResumed(activity: Activity) {
        currentActivity = activity
    }
    override fun onActivityPaused(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {
        if (currentActivity == activity) {
            currentActivity = null
        }
    }
}
