package com.educationwithhassan.pdfimageconverter.admob

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * RewardedAdManager
 * Centralized manager for AdMob Rewarded Video Ads (ID: ca-app-pub-3133971041724338/7960667830).
 */
object RewardedAdManager {

    private const val TAG = "RewardedAdManager"

    @Volatile
    private var rewardedAd: RewardedAd? = null

    @Volatile
    private var isLoading = false

    @Volatile
    private var isShowing = false

    private var appContext: Context? = null

    val isAdAvailable: Boolean
        get() = rewardedAd != null && !isShowing

    fun initialize(context: Context) {
        if (appContext == null) {
            appContext = context.applicationContext
            loadAd()
        }
    }

    @Synchronized
    fun loadAd() {
        val context = appContext ?: return
        if (isLoading || rewardedAd != null) return

        isLoading = true
        Log.d(TAG, "Loading Rewarded Ad with Unit: ${AdMobManager.rewardedAdUnitId}")

        try {
            val adRequest = AdRequest.Builder().build()
            RewardedAd.load(
                context,
                AdMobManager.rewardedAdUnitId,
                adRequest,
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        Log.d(TAG, "Rewarded Ad loaded and ready.")
                        rewardedAd = ad
                        isLoading = false
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        Log.w(TAG, "Rewarded Ad failed to load: ${loadAdError.message} (code: ${loadAdError.code})")
                        rewardedAd = null
                        isLoading = false
                    }
                }
            )
        } catch (e: Throwable) {
            Log.e(TAG, "Exception during Rewarded Ad load: ${e.message}")
            isLoading = false
        }
    }

    fun showRewardedAd(
        activity: Activity?,
        onRewardEarned: (RewardItem) -> Unit,
        onAdDismissed: () -> Unit = {}
    ) {
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            onAdDismissed()
            return
        }

        val adToShow: RewardedAd
        synchronized(this) {
            val ad = rewardedAd
            if (ad == null || isShowing) {
                Log.w(TAG, "Rewarded Ad is not ready. Initiating load.")
                loadAd()
                onAdDismissed()
                return
            }
            isShowing = true
            adToShow = ad
            rewardedAd = null
        }

        adToShow.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "Rewarded ad dismissed.")
                isShowing = false
                loadAd()
                onAdDismissed()
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.w(TAG, "Rewarded ad failed to show: ${adError.message}")
                isShowing = false
                loadAd()
                onAdDismissed()
            }

            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "Rewarded ad showed on screen.")
            }
        }

        try {
            adToShow.show(activity) { rewardItem ->
                Log.d(TAG, "User earned reward: ${rewardItem.amount} ${rewardItem.type}")
                onRewardEarned(rewardItem)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error showing Rewarded ad: ${e.message}")
            isShowing = false
            onAdDismissed()
        }
    }
}
