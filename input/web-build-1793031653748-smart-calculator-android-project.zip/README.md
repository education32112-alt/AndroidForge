# Smart Calculator — Android Application

**Developed by:** Education With Hassan  
**Package:** `com.educationwithhassan.smartcalculator`  
**Target:** Android 7.0+ (API 24 to API 34)  
**UI Framework:** Jetpack Compose (Material 3)  
**Architecture:** Clean MVVM (UI, ViewModel, Engine, Data)  
**Offline & Privacy:** 100% Offline, Zero Ads, Zero Tracking, Zero Permissions  

---

## Key Features

1. **Precision Arithmetic Engine**: Addition, subtraction, multiplication, division, decimal input, unary negatives, percentages, parentheses, and operator precedence using the Shunting-Yard Algorithm.
2. **Scientific Calculator**:
   - Trigonometric: `sin`, `cos`, `tan`, `asin`, `acos`, `atan`
   - Angle Modes: DEG (Degrees) & RAD (Radians) with instant live indicator
   - Logarithmic: Base-10 (`log`) and Natural Log (`ln`)
   - Exponential & Powers: `x²`, `xʸ` (`^`), `1/x` (reciprocal)
   - Advanced: Square root (`√`), Factorial (`n!`), Absolute value (`|x|`), Constants (`π`, `e`)
3. **Hardware & Tactile Memory Operations**:
   - `MC`: Memory Clear
   - `MR`: Memory Recall
   - `M+`: Add current result/operand to memory
   - `M−`: Subtract current result/operand from memory
   - `MS`: Memory Store with visible active `[M]` indicator
4. **Local Calculation History**:
   - Automatically stores every successful computation locally.
   - Tap any record to immediately reuse either expression or result.
   - Copy expression/result to clipboard with visual toast feedback.
   - Clear history with safety confirmation dialog.
5. **Color & Theme System**:
   - Deep Navy (`#101827`), Dark Navy Surface (`#172338`), Blue (`#2878FF`), Violet (`#7657FF`), Cyan Accent (`#26C6DA`), Light Background (`#F5F7FC`), Error Red (`#D93045`).
   - Supports System Default, Light Theme, and Dark Theme.
6. **Edge-to-Edge & Responsive**:
   - Fluid key layout for small, medium, and large phones.
   - Handles portrait and landscape orientations gracefully without clipping.

---

## Opening the Project in Android Studio

1. Download the complete project archive (`smart-calculator-android-project.zip`) or clone the repo.
2. Unzip into your development folder (e.g., `~/AndroidStudioProjects/SmartCalculator`).
3. Open **Android Studio** (Koala, Ladybug, or HedgeHog with JDK 17).
4. Select **File > Open...** and navigate to the project root containing `settings.gradle.kts`.
5. Allow Gradle to sync dependencies automatically.
6. Select an emulator or connected physical Android device and click **Run** (green triangle) or press `Shift + F10`.

---

## Building the Debug APK

Run the Gradle wrapper command from the project root:

```bash
./gradlew assembleDebug
```

The generated APK will be available at:
`app/build/outputs/apk/debug/app-debug.apk`

To run the complete automated test suite:
```bash
./gradlew test
```

---

## OPPO App Market Submission Checklist

1. **App Identity**:
   - App Name: Smart Calculator
   - Package Name: `com.educationwithhassan.smartcalculator`
   - Category: Tools / Education / Productivity
2. **Release Signing**:
   - Generate an upload keystore via **Build > Generate Signed Bundle / APK**.
   - Create a Release build: `./gradlew assembleRelease`.
3. **No-Ads Compliance**:
   - Confirmed: Zero AdMob SDKs, zero advertising IDs, zero telemetry.
4. **Offline & Privacy Policy**:
   - Includes in-app privacy policy stating zero data collection.
5. **Assets Needed**:
   - 512x512 PNG app icon (rounded square, no copyright infringements).
   - At least 3 phone screenshots (1080x1920 or 1080x2400) showing Home, Scientific Mode, and History.
