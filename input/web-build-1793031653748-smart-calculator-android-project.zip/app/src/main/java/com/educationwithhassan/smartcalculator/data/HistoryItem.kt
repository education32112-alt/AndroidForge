package com.educationwithhassan.smartcalculator.data

data class HistoryItem(
    val id: String = System.currentTimeMillis().toString(),
    val expression: String,
    val result: String,
    val numericValue: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val angleMode: String = "DEG"
)
