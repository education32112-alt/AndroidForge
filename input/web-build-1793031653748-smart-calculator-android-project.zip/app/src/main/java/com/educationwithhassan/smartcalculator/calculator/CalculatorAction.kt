package com.educationwithhassan.smartcalculator.calculator

sealed interface CalculatorAction {
    data class Number(val digit: Int) : CalculatorAction
    data class Operator(val symbol: String) : CalculatorAction
    data class ScientificFunction(val func: String) : CalculatorAction
    data class Constant(val symbol: String) : CalculatorAction
    object Decimal : CalculatorAction
    object Clear : CalculatorAction
    object Backspace : CalculatorAction
    object Calculate : CalculatorAction
    object ToggleSign : CalculatorAction
    object Percentage : CalculatorAction
    object Parentheses : CalculatorAction
    object ToggleScientific : CalculatorAction
    object ToggleAngleMode : CalculatorAction
    object MemoryClear : CalculatorAction
    object MemoryRecall : CalculatorAction
    object MemoryAdd : CalculatorAction
    object MemorySubtract : CalculatorAction
    object MemoryStore : CalculatorAction
    data class RestoreHistory(val expression: String, val result: String) : CalculatorAction
    object ClearHistory : CalculatorAction
}
