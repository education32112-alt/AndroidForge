package com.educationwithhassan.smartcalculator.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.smartcalculator.calculator.CalculatorAction

@Composable
fun KeypadSection(
    isScientific: Boolean,
    onAction: (CalculatorAction) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (isScientific) {
            // Scientific Rows
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CalculatorButton("sin", { onAction(CalculatorAction.ScientificFunction("sin")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
                CalculatorButton("cos", { onAction(CalculatorAction.ScientificFunction("cos")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
                CalculatorButton("tan", { onAction(CalculatorAction.ScientificFunction("tan")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
                CalculatorButton("π", { onAction(CalculatorAction.Constant("π")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
                CalculatorButton("e", { onAction(CalculatorAction.Constant("e")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CalculatorButton("√", { onAction(CalculatorAction.ScientificFunction("sqrt")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
                CalculatorButton("xʸ", { onAction(CalculatorAction.Operator("^")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
                CalculatorButton("log", { onAction(CalculatorAction.ScientificFunction("log")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
                CalculatorButton("ln", { onAction(CalculatorAction.ScientificFunction("ln")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
                CalculatorButton("n!", { onAction(CalculatorAction.ScientificFunction("fact")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CalculatorButton("asin", { onAction(CalculatorAction.ScientificFunction("asin")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 14.sp, height = 48.dp)
                CalculatorButton("acos", { onAction(CalculatorAction.ScientificFunction("acos")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 14.sp, height = 48.dp)
                CalculatorButton("atan", { onAction(CalculatorAction.ScientificFunction("atan")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 14.sp, height = 48.dp)
                CalculatorButton("(", { onAction(CalculatorAction.Operator("(")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
                CalculatorButton(")", { onAction(CalculatorAction.Operator(")")) }, Modifier.weight(1f), ButtonType.FUNCTION, fontSize = 16.sp, height = 48.dp)
            }
            Spacer(modifier = Modifier.height(2.dp))
        }

        // Standard 5 Keypad Rows
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorButton("AC", { onAction(CalculatorAction.Clear) }, Modifier.weight(1f), ButtonType.CLEAR)
            CalculatorButton("⌫", { onAction(CalculatorAction.Backspace) }, Modifier.weight(1f), ButtonType.ACTION)
            CalculatorButton("%", { onAction(CalculatorAction.Percentage) }, Modifier.weight(1f), ButtonType.OPERATOR)
            CalculatorButton("÷", { onAction(CalculatorAction.Operator("÷")) }, Modifier.weight(1f), ButtonType.OPERATOR)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorButton("7", { onAction(CalculatorAction.Number(7)) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton("8", { onAction(CalculatorAction.Number(8)) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton("9", { onAction(CalculatorAction.Number(9)) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton("×", { onAction(CalculatorAction.Operator("×")) }, Modifier.weight(1f), ButtonType.OPERATOR)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorButton("4", { onAction(CalculatorAction.Number(4)) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton("5", { onAction(CalculatorAction.Number(5)) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton("6", { onAction(CalculatorAction.Number(6)) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton("−", { onAction(CalculatorAction.Operator("−")) }, Modifier.weight(1f), ButtonType.OPERATOR)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorButton("1", { onAction(CalculatorAction.Number(1)) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton("2", { onAction(CalculatorAction.Number(2)) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton("3", { onAction(CalculatorAction.Number(3)) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton("+", { onAction(CalculatorAction.Operator("+")) }, Modifier.weight(1f), ButtonType.OPERATOR)
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorButton("+/-", { onAction(CalculatorAction.ToggleSign) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton("0", { onAction(CalculatorAction.Number(0)) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton(".", { onAction(CalculatorAction.Decimal) }, Modifier.weight(1f), ButtonType.NUMBER)
            CalculatorButton("=", { onAction(CalculatorAction.Calculate) }, Modifier.weight(1f), ButtonType.EQUALS)
        }
    }
}
