package com.educationwithhassan.smartcalculator.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.educationwithhassan.smartcalculator.calculator.*
import com.educationwithhassan.smartcalculator.data.HistoryItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class CalculatorViewModel(
    private val engine: CalculatorEngine = CalculatorEngine()
) : ViewModel() {

    private val _state = MutableStateFlow(CalculatorState())
    val state: StateFlow<CalculatorState> = _state.asStateFlow()

    fun onAction(action: CalculatorAction) {
        when (action) {
            is CalculatorAction.Number -> handleNumber(action.digit)
            is CalculatorAction.Operator -> handleOperator(action.symbol)
            is CalculatorAction.Decimal -> handleDecimal()
            is CalculatorAction.Clear -> handleClear()
            is CalculatorAction.Backspace -> handleBackspace()
            is CalculatorAction.Calculate -> handleCalculate()
            is CalculatorAction.ToggleSign -> handleToggleSign()
            is CalculatorAction.Percentage -> handlePercentage()
            is CalculatorAction.Parentheses -> handleParentheses()
            is CalculatorAction.ScientificFunction -> handleScientificFunction(action.func)
            is CalculatorAction.Constant -> handleConstant(action.symbol)
            is CalculatorAction.ToggleScientific -> {
                _state.update { it.copy(isScientific = !it.isScientific) }
            }
            is CalculatorAction.ToggleAngleMode -> {
                val newMode = if (_state.value.angleMode == AngleMode.DEG) AngleMode.RAD else AngleMode.DEG
                _state.update { it.copy(angleMode = newMode) }
                updateLivePreview()
            }
            is CalculatorAction.MemoryClear -> {
                _state.update { it.copy(memoryValue = 0.0, hasMemory = false) }
            }
            is CalculatorAction.MemoryRecall -> {
                if (_state.value.hasMemory) {
                    val formatted = engine.formatNumber(_state.value.memoryValue, _state.value.decimalPrecision)
                    _state.update { it.copy(expression = it.expression + formatted) }
                    updateLivePreview()
                }
            }
            is CalculatorAction.MemoryAdd -> {
                val current = getCurrentOrEvaluatedValue()
                if (current != null) {
                    val updated = _state.value.memoryValue + current
                    _state.update { it.copy(memoryValue = updated, hasMemory = true) }
                }
            }
            is CalculatorAction.MemorySubtract -> {
                val current = getCurrentOrEvaluatedValue()
                if (current != null) {
                    val updated = _state.value.memoryValue - current
                    _state.update { it.copy(memoryValue = updated, hasMemory = true) }
                }
            }
            is CalculatorAction.MemoryStore -> {
                val current = getCurrentOrEvaluatedValue()
                if (current != null) {
                    _state.update { it.copy(memoryValue = current, hasMemory = true) }
                }
            }
            is CalculatorAction.RestoreHistory -> {
                _state.update {
                    it.copy(
                        expression = action.expression,
                        result = action.result,
                        previewResult = "",
                        isEvaluated = true,
                        errorMessage = null
                    )
                }
            }
            is CalculatorAction.ClearHistory -> {
                _state.update { it.copy(history = emptyList()) }
            }
        }
    }

    private fun handleNumber(digit: Int) {
        _state.update {
            val base = if (it.isEvaluated) "" else it.expression
            val newExpr = base + digit.toString()
            it.copy(
                expression = newExpr,
                isEvaluated = false,
                errorMessage = null
            )
        }
        updateLivePreview()
    }

    private fun handleOperator(symbol: String) {
        _state.update {
            val expr = if (it.isEvaluated) it.result else it.expression
            val formattedSymbol = " $symbol "
            val newExpr = if (expr.isEmpty()) {
                if (symbol == "-") "-" else ""
            } else if (expr.endsWith(" + ") || expr.endsWith(" − ") || expr.endsWith(" × ") || expr.endsWith(" ÷ ")) {
                expr.substring(0, expr.length - 3) + formattedSymbol
            } else {
                expr + formattedSymbol
            }
            it.copy(
                expression = newExpr,
                isEvaluated = false,
                errorMessage = null
            )
        }
        updateLivePreview()
    }

    private fun handleDecimal() {
        _state.update {
            val base = if (it.isEvaluated) "0" else it.expression
            // Don't add double decimals in same number chunk
            val lastPart = base.split(" ", "(", ")", "+", "-", "×", "÷").lastOrNull() ?: ""
            if (!lastPart.contains(".")) {
                val newExpr = if (base.isEmpty() || base.endsWith(" ")) base + "0." else base + "."
                it.copy(expression = newExpr, isEvaluated = false)
            } else it
        }
        updateLivePreview()
    }

    private fun handleClear() {
        _state.update {
            it.copy(
                expression = "",
                result = "0",
                previewResult = "",
                isEvaluated = false,
                errorMessage = null
            )
        }
    }

    private fun handleBackspace() {
        _state.update {
            if (it.expression.isNotEmpty()) {
                val trimmed = if (it.expression.endsWith(" ")) {
                    it.expression.dropLast(3) // drop " + "
                } else {
                    it.expression.dropLast(1)
                }
                it.copy(expression = trimmed, errorMessage = null)
            } else it
        }
        updateLivePreview()
    }

    private fun handleCalculate() {
        val currentExpr = _state.value.expression
        if (currentExpr.isBlank()) return

        val calcResult = engine.evaluate(currentExpr, _state.value.angleMode, _state.value.decimalPrecision)
        if (calcResult.isSuccess) {
            val newHistoryItem = HistoryItem(
                expression = currentExpr,
                result = calcResult.formattedResult,
                numericValue = calcResult.value,
                angleMode = _state.value.angleMode.name
            )
            _state.update {
                it.copy(
                    result = calcResult.formattedResult,
                    previewResult = "",
                    isEvaluated = true,
                    errorMessage = null,
                    history = listOf(newHistoryItem) + it.history
                )
            }
        } else {
            _state.update {
                it.copy(
                    errorMessage = calcResult.errorMessage ?: "Error",
                    previewResult = ""
                )
            }
        }
    }

    private fun handleToggleSign() {
        _state.update {
            if (it.expression.startsWith("-")) {
                it.copy(expression = it.expression.drop(1))
            } else if (it.expression.isNotEmpty()) {
                it.copy(expression = "-(" + it.expression + ")")
            } else it
        }
        updateLivePreview()
    }

    private fun handlePercentage() {
        _state.update {
            if (it.expression.isNotEmpty() && !it.expression.endsWith("%")) {
                it.copy(expression = it.expression + "%")
            } else it
        }
        updateLivePreview()
    }

    private fun handleParentheses() {
        _state.update {
            val openCount = it.expression.count { c -> c == '(' }
            val closeCount = it.expression.count { c -> c == ')' }
            val needsClose = openCount > closeCount && !it.expression.endsWith("(") && !it.expression.endsWith(" ")
            val charToAdd = if (needsClose) ")" else "("
            it.copy(expression = it.expression + charToAdd)
        }
        updateLivePreview()
    }

    private fun handleScientificFunction(func: String) {
        _state.update {
            val base = if (it.isEvaluated) "" else it.expression
            it.copy(
                expression = "$base$func(",
                isEvaluated = false,
                errorMessage = null
            )
        }
        updateLivePreview()
    }

    private fun handleConstant(symbol: String) {
        _state.update {
            val base = if (it.isEvaluated) "" else it.expression
            it.copy(
                expression = "$base$symbol",
                isEvaluated = false,
                errorMessage = null
            )
        }
        updateLivePreview()
    }

    private fun updateLivePreview() {
        val expr = _state.value.expression
        if (expr.length >= 2) {
            val res = engine.evaluate(expr, _state.value.angleMode, _state.value.decimalPrecision)
            if (res.isSuccess) {
                _state.update { it.copy(previewResult = res.formattedResult, errorMessage = null) }
            } else {
                _state.update { it.copy(previewResult = "") }
            }
        } else {
            _state.update { it.copy(previewResult = "") }
        }
    }

    private fun getCurrentOrEvaluatedValue(): Double? {
        val currentExpr = _state.value.expression
        if (_state.value.isEvaluated) {
            return _state.value.result.toDoubleOrNull()
        }
        if (currentExpr.isNotEmpty()) {
            val res = engine.evaluate(currentExpr, _state.value.angleMode, _state.value.decimalPrecision)
            if (res.isSuccess) return res.value
        }
        return null
    }
}
