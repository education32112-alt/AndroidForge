package com.educationwithhassan.smartcalculator.admob

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.*
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback

/**
 * Production AdMob Manager for Smart Calculator
 * Developer: Education With Hassan
 * Publisher ID: pub-3133971041724338
 */
object AdMobConstants {
    const val APP_ID = "ca-app-pub-3133971041724338~2012097344"
    const val BANNER_ID = "ca-app-pub-3133971041724338/1521142752"
    const val INTERSTITIAL_ID = "ca-app-pub-3133971041724338/7237423733"
    const val REWARDED_INTERSTITIAL_BETA_ID = "ca-app-pub-3133971041724338/5872371179"
    const val REWARDED_ID = "ca-app-pub-3133971041724338/4611260396"
    const val NATIVE_ADVANCED_ID = "ca-app-pub-3133971041724338/3226648655"
    const val APP_OPEN_ID = "ca-app-pub-3133971041724338/8287403647"
}

class AdMobManager private constructor() {

    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var rewardedInterstitialAd: RewardedInterstitialAd? = null
    private var appOpenAd: AppOpenAd? = null
    private var isAppOpenLoading = false
    private var isInitialized = false

    companion object {
        private const val TAG = "AdMobManager"
        @Volatile
        private var instance: AdMobManager? = null

        fun getInstance(): AdMobManager {
            return instance ?: synchronized(this) {
                instance ?: AdMobManager().also { instance = it }
            }
        }
    }

    fun initialize(context: Context, onComplete: (() -> Unit)? = null) {
        if (isInitialized) {
            onComplete?.invoke()
            return
        }
        MobileAds.initialize(context) { status ->
            Log.d(TAG, "AdMob Initialized: ${status.adapterStatusMap}")
            isInitialized = true
            loadInterstitial(context)
            loadRewarded(context)
            loadRewardedInterstitial(context)
            loadAppOpenAd(context)
            onComplete?.invoke()
        }
    }

    // 1. BANNER AD SETUP
    fun setupBanner(adView: AdView) {
        adView.adUnitId = AdMobConstants.BANNER_ID
        adView.setAdSize(AdSize.BANNER)
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
    }

    // 2. INTERSTITIAL AD
    fun loadInterstitial(context: Context) {
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            AdMobConstants.INTERSTITIAL_ID,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    Log.d(TAG, "Interstitial Ad Loaded successfully")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    Log.w(TAG, "Interstitial Ad Failed to load: ${error.message}")
                }
            }
        )
    }

    fun showInterstitial(activity: Activity, onDismissed: (() -> Unit)? = null) {
        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onDismissed?.invoke()
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onDismissed?.invoke()
                }
            }
            ad.show(activity)
        } else {
            loadInterstitial(activity)
            onDismissed?.invoke()
        }
    }

    // 3. REWARDED AD
    fun loadRewarded(context: Context) {
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            AdMobConstants.REWARDED_ID,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    Log.d(TAG, "Rewarded Ad Loaded successfully")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                    Log.w(TAG, "Rewarded Ad Failed: ${error.message}")
                }
            }
        )
    }

    fun showRewarded(activity: Activity, onRewardEarned: (Int) -> Unit, onDismissed: (() -> Unit)? = null) {
        val ad = rewardedAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewarded(activity)
                    onDismissed?.invoke()
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    loadRewarded(activity)
                    onDismissed?.invoke()
                }
            }
            ad.show(activity) { rewardItem ->
                onRewardEarned(rewardItem.amount)
            }
        } else {
            loadRewarded(activity)
            onDismissed?.invoke()
        }
    }

    // 4. REWARDED INTERSTITIAL (BETA)
    fun loadRewardedInterstitial(context: Context) {
        val adRequest = AdRequest.Builder().build()
        RewardedInterstitialAd.load(
            context,
            AdMobConstants.REWARDED_INTERSTITIAL_BETA_ID,
            adRequest,
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) {
                    rewardedInterstitialAd = ad
                    Log.d(TAG, "Rewarded Interstitial Ad Loaded")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedInterstitialAd = null
                    Log.w(TAG, "Rewarded Interstitial Failed: ${error.message}")
                }
            }
        )
    }

    fun showRewardedInterstitial(activity: Activity, onRewardEarned: (Int) -> Unit) {
        rewardedInterstitialAd?.show(activity) { rewardItem ->
            onRewardEarned(rewardItem.amount)
            loadRewardedInterstitial(activity)
        } ?: run {
            loadRewardedInterstitial(activity)
        }
    }

    // 5. NATIVE ADVANCED AD
    fun loadNativeAd(context: Context, onNativeLoaded: (NativeAd) -> Unit) {
        val adLoader = AdLoader.Builder(context, AdMobConstants.NATIVE_ADVANCED_ID)
            .forNativeAd { nativeAd ->
                onNativeLoaded(nativeAd)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Native Ad Failed: ${error.message}")
                }
            })
            .withNativeAdOptions(NativeAdOptions.Builder().build())
            .build()

        adLoader.loadAd(AdRequest.Builder().build())
    }

    // 6. APP OPEN AD (SPLASH & RESUME)
    fun loadAppOpenAd(context: Context) {
        if (isAppOpenLoading || appOpenAd != null) return
        isAppOpenLoading = true
        val adRequest = AdRequest.Builder().build()
        AppOpenAd.load(
            context,
            AdMobConstants.APP_OPEN_ID,
            adRequest,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    isAppOpenLoading = false
                    Log.d(TAG, "App Open Ad Loaded")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    appOpenAd = null
                    isAppOpenLoading = false
                    Log.w(TAG, "App Open Ad Failed: ${error.message}")
                }
            }
        )
    }

    fun showAppOpenAd(activity: Activity, onComplete: () -> Unit) {
        val ad = appOpenAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    appOpenAd = null
                    loadAppOpenAd(activity)
                    onComplete()
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    appOpenAd = null
                    loadAppOpenAd(activity)
                    onComplete()
                }
            }
            ad.show(activity)
        } else {
            loadAppOpenAd(activity)
            onComplete()
        }
    }
}
