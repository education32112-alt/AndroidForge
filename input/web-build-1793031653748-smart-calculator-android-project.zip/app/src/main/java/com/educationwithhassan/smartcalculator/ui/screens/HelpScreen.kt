package com.educationwithhassan.smartcalculator.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.smartcalculator.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(onNavigateBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Help & Instructions", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                HelpCard(
                    title = "1. Basic Calculations & Precedence",
                    content = "Enter operations normally. The calculator strictly follows standard algebraic order of operations (Parentheses, Exponents, Multiplication & Division, Addition & Subtraction). For example, 2 + 3 × 4 evaluates to 14, while (2 + 3) × 4 evaluates to 20."
                )
            }
            item {
                HelpCard(
                    title = "2. Scientific Functions & Trigonometry",
                    content = "Tap the Science icon in the top bar to toggle trigonometric (sin, cos, tan, asin, acos, atan), logarithmic (log, ln), and exponential functions. Tap DEG/RAD to toggle between Degree and Radian angle units."
                )
            }
            item {
                HelpCard(
                    title = "3. Memory Functions (MC, MR, M+, M−, MS)",
                    content = "• MC: Memory Clear (resets stored memory to 0)\n• MR: Memory Recall (inserts the stored memory number into the expression)\n• M+: Adds the current evaluated number into memory\n• M−: Subtracts the current evaluated number from memory\n• MS: Memory Store (overwrites memory with current number)\nA visible [M] badge appears whenever memory contains a value."
                )
            }
            item {
                HelpCard(
                    title = "4. Percentage (%) Behavior",
                    content = "Enter expressions such as 100 × 25% (= 25) or 50% (= 0.5). The engine converts the percentage value to its fractional equivalent (/ 100)."
                )
            }
            item {
                HelpCard(
                    title = "5. Calculation History",
                    content = "Every successful computation is automatically saved locally. Tap the clock/history icon in the top bar to review past calculations, restore an expression or result, or copy values."
                )
            }
            item {
                HelpCard(
                    title = "6. Error Handling",
                    content = "If an invalid operation is attempted (such as division by zero, negative square root, or unbalanced parentheses), the display safely presents a clear error message instead of crashing."
                )
            }
        }
    }
}

@Composable
fun HelpCard(title: String, content: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = content, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface, lineHeight = 20.sp)
        }
    }
}
