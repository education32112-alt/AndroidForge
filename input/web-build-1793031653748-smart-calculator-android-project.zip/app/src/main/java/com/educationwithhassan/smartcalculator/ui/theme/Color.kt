package com.educationwithhassan.smartcalculator.ui.theme

import androidx.compose.ui.graphics.Color

// Required Brand Color Palette
val DeepNavy = Color(0xFF101827)
val DarkNavySurface = Color(0xFF172338)
val DarkNavyElevated = Color(0xFF1E2D47)
val BluePrimary = Color(0xFF2878FF)
val VioletSecondary = Color(0xFF7657FF)
val CyanAccent = Color(0xFF26C6DA)
val LightBackground = Color(0xFFF5F7FC)
val WhiteSurface = Color(0xFFFFFFFF)
val TextMainLight = Color(0xFF182230)
val TextMainDark = Color(0xFFF0F4FA)
val TextSecondary = Color(0xFF788398)
val ErrorColor = Color(0xFFD93045)
val NumberKeyDark = Color(0xFF202E46)
val NumberKeyLight = Color(0xFFFFFFFF)
val OpKeyDark = Color(0xFF273855)
val OpKeyLight = Color(0xFFE9EDF7)
