package com.educationwithhassan.smartcalculator.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.smartcalculator.ui.theme.CyanAccent
import com.educationwithhassan.smartcalculator.ui.theme.TextSecondary

@Composable
fun MemoryBar(
    hasMemory: Boolean,
    onClear: () -> Unit,
    onRecall: () -> Unit,
    onAdd: () -> Unit,
    onSubtract: () -> Unit,
    onStore: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val memoryKeys = listOf(
            Triple("MC", onClear, hasMemory),
            Triple("MR", onRecall, hasMemory),
            Triple("M+", onAdd, true),
            Triple("M−", onSubtract, true),
            Triple("MS", onStore, true)
        )

        for ((label, action, enabled) in memoryKeys) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(enabled = enabled) { action() }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (enabled) {
                        if (hasMemory && (label == "MC" || label == "MR")) CyanAccent
                        else MaterialTheme.colorScheme.onSurface
                    } else TextSecondary.copy(alpha = 0.4f)
                )
            }
        }
    }
}
