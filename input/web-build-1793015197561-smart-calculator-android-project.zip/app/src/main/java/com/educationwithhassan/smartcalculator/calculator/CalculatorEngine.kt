package com.educationwithhassan.smartcalculator.calculator

import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Stack
import kotlin.math.*

enum class AngleMode {
    DEG, RAD
}

data class CalculationResult(
    val isSuccess: Boolean,
    val value: Double = 0.0,
    val formattedResult: String = "",
    val errorMessage: String? = null
)

/**
 * Robust, Safe Mathematical Expression Parser and Evaluation Engine
 * Built for Education With Hassan - Smart Calculator
 * Implements Shunting-Yard Algorithm with operator precedence, parentheses,
 * scientific functions, trigonometric conversion, and domain validation.
 */
class CalculatorEngine {

    private sealed class Token {
        data class NumberToken(val value: Double) : Token()
        data class OperatorToken(val op: Char, val precedence: Int, val isRightAssociative: Boolean = false) : Token()
        data class FunctionToken(val name: String) : Token()
        object LeftParen : Token()
        object RightParen : Token()
        object PercentToken : Token()
        object UnaryMinus : Token()
    }

    /**
     * Evaluates a mathematical expression safely.
     */
    fun evaluate(expression: String, angleMode: AngleMode = AngleMode.DEG, precision: Int = 8): CalculationResult {
        val trimmed = expression.trim()
        if (trimmed.isEmpty()) {
            return CalculationResult(isSuccess = false, errorMessage = "Empty expression")
        }

        return try {
            val tokens = tokenize(trimmed)
            val rpn = toRPN(tokens)
            val resultValue = evaluateRPN(rpn, angleMode)
            val formatted = formatNumber(resultValue, precision)
            CalculationResult(isSuccess = true, value = resultValue, formattedResult = formatted)
        } catch (e: ArithmeticException) {
            CalculationResult(isSuccess = false, errorMessage = e.message ?: "Math error")
        } catch (e: IllegalArgumentException) {
            CalculationResult(isSuccess = false, errorMessage = e.message ?: "Invalid syntax")
        } catch (e: Exception) {
            CalculationResult(isSuccess = false, errorMessage = "Error: ${e.localizedMessage ?: "Invalid input"}")
        }
    }

    private fun tokenize(raw: String): List<Token> {
        val cleaned = raw
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace("\s+".toRegex(), "")

        val tokens = mutableListOf<Token>()
        var i = 0

        while (i < cleaned.length) {
            val c = cleaned[i]

            // Numbers
            if (c.isDigit() || c == '.') {
                val sb = StringBuilder()
                var dotCount = 0
                while (i < cleaned.length && (cleaned[i].isDigit() || cleaned[i] == '.' || cleaned[i] == 'e' || cleaned[i] == 'E')) {
                    if (cleaned[i] == '.') {
                        dotCount++
                        if (dotCount > 1) throw IllegalArgumentException("Multiple decimal points in number")
                    }
                    if (cleaned[i] == 'e' || cleaned[i] == 'E') {
                        sb.append(cleaned[i++])
                        if (i < cleaned.length && (cleaned[i] == '+' || cleaned[i] == '-')) {
                            sb.append(cleaned[i++])
                        }
                        continue
                    }
                    sb.append(cleaned[i++])
                }
                tokens.add(Token.NumberToken(sb.toString().toDouble()))
                continue
            }

            // Word tokens (functions and constants)
            if (c.isLetter() || c == 'π') {
                val sb = StringBuilder()
                while (i < cleaned.length && (cleaned[i].isLetter() || cleaned[i].isDigit() || cleaned[i] == 'π')) {
                    sb.append(cleaned[i++])
                }
                val name = sb.toString().lowercase()
                when (name) {
                    "pi", "π" -> tokens.add(Token.NumberToken(Math.PI))
                    "e" -> tokens.add(Token.NumberToken(Math.E))
                    "sin", "cos", "tan", "asin", "acos", "atan",
                    "log", "ln", "sqrt", "abs", "fact" -> tokens.add(Token.FunctionToken(name))
                    else -> throw IllegalArgumentException("Unknown identifier: $name")
                }
                continue
            }

            // Operators & Parens
            when (c) {
                '+' -> { tokens.add(Token.OperatorToken('+', 2)); i++ }
                '-' -> {
                    // Check if unary minus
                    val prev = tokens.lastOrNull()
                    if (prev == null || prev is Token.OperatorToken || prev is Token.LeftParen || prev is Token.UnaryMinus) {
                        tokens.add(Token.UnaryMinus)
                    } else {
                        tokens.add(Token.OperatorToken('-', 2))
                    }
                    i++
                }
                '*' -> { tokens.add(Token.OperatorToken('*', 3)); i++ }
                '/' -> { tokens.add(Token.OperatorToken('/', 3)); i++ }
                '^' -> { tokens.add(Token.OperatorToken('^', 4, isRightAssociative = true)); i++ }
                '%' -> { tokens.add(Token.PercentToken); i++ }
                '(' -> { tokens.add(Token.LeftParen); i++ }
                ')' -> { tokens.add(Token.RightParen); i++ }
                else -> throw IllegalArgumentException("Unexpected character: $c")
            }
        }

        // Handle implicit multiplication (e.g. 2(3) -> 2*(3), 2π -> 2*π)
        val expanded = mutableListOf<Token>()
        for (idx in tokens.indices) {
            val curr = tokens[idx]
            expanded.add(curr)
            if (idx + 1 < tokens.size) {
                val next = tokens[idx + 1]
                val currCanMultiply = curr is Token.NumberToken || curr is Token.RightParen || curr is Token.PercentToken
                val nextCanBeMultiplied = next is Token.NumberToken || next is Token.LeftParen || next is Token.FunctionToken
                if (currCanMultiply && nextCanBeMultiplied) {
                    expanded.add(Token.OperatorToken('*', 3))
                }
            }
        }

        return expanded
    }

    private fun toRPN(tokens: List<Token>): List<Token> {
        val output = mutableListOf<Token>()
        val stack = Stack<Token>()

        for (token in tokens) {
            when (token) {
                is Token.NumberToken, is Token.PercentToken -> output.add(token)
                is Token.FunctionToken -> stack.push(token)
                is Token.UnaryMinus -> stack.push(token)
                is Token.OperatorToken -> {
                    while (stack.isNotEmpty()) {
                        val top = stack.peek()
                        if (top is Token.FunctionToken || top is Token.UnaryMinus) {
                            output.add(stack.pop())
                            continue
                        }
                        if (top is Token.OperatorToken) {
                            val p1 = token.precedence
                            val p2 = top.precedence
                            if ((!token.isRightAssociative && p1 <= p2) || (token.isRightAssociative && p1 < p2)) {
                                output.add(stack.pop())
                            } else break
                        } else break
                    }
                    stack.push(token)
                }
                is Token.LeftParen -> stack.push(token)
                is Token.RightParen -> {
                    var matched = false
                    while (stack.isNotEmpty()) {
                        val top = stack.pop()
                        if (top is Token.LeftParen) {
                            matched = true
                            break
                        }
                        output.add(top)
                    }
                    if (!matched) throw IllegalArgumentException("Mismatched parentheses")
                    if (stack.isNotEmpty() && stack.peek() is Token.FunctionToken) {
                        output.add(stack.pop())
                    }
                }
            }
        }

        while (stack.isNotEmpty()) {
            val top = stack.pop()
            if (top is Token.LeftParen || top is Token.RightParen) {
                throw IllegalArgumentException("Mismatched parentheses")
            }
            output.add(top)
        }

        return output
    }

    private fun evaluateRPN(rpn: List<Token>, angleMode: AngleMode): Double {
        val stack = Stack<Double>()

        fun toRad(deg: Double) = if (angleMode == AngleMode.DEG) deg * Math.PI / 180.0 else deg
        fun fromRad(rad: Double) = if (angleMode == AngleMode.DEG) rad * 180.0 / Math.PI else rad

        for (token in rpn) {
            when (token) {
                is Token.NumberToken -> stack.push(token.value)
                is Token.PercentToken -> {
                    if (stack.isEmpty()) throw IllegalArgumentException("Invalid percentage syntax")
                    stack.push(stack.pop() / 100.0)
                }
                is Token.UnaryMinus -> {
                    if (stack.isEmpty()) throw IllegalArgumentException("Missing operand for negation")
                    stack.push(-stack.pop())
                }
                is Token.OperatorToken -> {
                    if (stack.size < 2) throw IllegalArgumentException("Incomplete expression")
                    val b = stack.pop()
                    val a = stack.pop()
                    when (token.op) {
                        '+' -> stack.push(a + b)
                        '-' -> stack.push(a - b)
                        '*' -> stack.push(a * b)
                        '/' -> {
                            if (b == 0.0) throw ArithmeticException("Cannot divide by zero")
                            stack.push(a / b)
                        }
                        '^' -> {
                            if (a < 0.0 && floor(b) != b) throw ArithmeticException("Negative base with fractional power")
                            stack.push(a.pow(b))
                        }
                    }
                }
                is Token.FunctionToken -> {
                    if (stack.isEmpty()) throw IllegalArgumentException("Missing function argument")
                    val arg = stack.pop()
                    when (token.name) {
                        "sin" -> {
                            val s = sin(toRad(arg))
                            stack.push(if (abs(s) < 1e-15) 0.0 else s)
                        }
                        "cos" -> {
                            val c = cos(toRad(arg))
                            stack.push(if (abs(c) < 1e-15) 0.0 else c)
                        }
                        "tan" -> {
                            if (angleMode == AngleMode.DEG && abs(((arg % 180) + 180) % 180 - 90.0) < 1e-9) {
                                throw ArithmeticException("Tangent undefined at 90°")
                            }
                            val t = tan(toRad(arg))
                            stack.push(if (abs(t) < 1e-15) 0.0 else t)
                        }
                        "asin" -> {
                            if (arg < -1.0 || arg > 1.0) throw ArithmeticException("Domain error: asin argument must be between -1 and 1")
                            stack.push(fromRad(asin(arg)))
                        }
                        "acos" -> {
                            if (arg < -1.0 || arg > 1.0) throw ArithmeticException("Domain error: acos argument must be between -1 and 1")
                            stack.push(fromRad(acos(arg)))
                        }
                        "atan" -> stack.push(fromRad(atan(arg)))
                        "log" -> {
                            if (arg <= 0.0) throw ArithmeticException("Domain error: log argument must be positive")
                            stack.push(log10(arg))
                        }
                        "ln" -> {
                            if (arg <= 0.0) throw ArithmeticException("Domain error: ln argument must be positive")
                            stack.push(ln(arg))
                        }
                        "sqrt" -> {
                            if (arg < 0.0) throw ArithmeticException("Domain error: cannot calculate square root of negative")
                            stack.push(sqrt(arg))
                        }
                        "abs" -> stack.push(abs(arg))
                        "fact" -> {
                            if (arg < 0.0 || floor(arg) != arg || arg > 170.0) {
                                throw ArithmeticException("Factorial requires non-negative integer <= 170")
                            }
                            var f = 1.0
                            for (k in 2..arg.toInt()) {
                                f *= k
                            }
                            stack.push(f)
                        }
                        else -> throw IllegalArgumentException("Unknown function: ${token.name}")
                    }
                }
                else -> throw IllegalArgumentException("Unexpected token in RPN evaluation")
            }
        }

        if (stack.size != 1) throw IllegalArgumentException("Malformed expression")
        val finalVal = stack.pop()
        if (finalVal.isInfinite() || finalVal.isNaN()) {
            throw ArithmeticException("Result overflow or undefined")
        }
        return finalVal
    }

    fun formatNumber(value: Double, precision: Int = 8): String {
        if (value.isNaN()) return "Error"
        if (value.isInfinite()) return if (value > 0) "Infinity" else "-Infinity"

        val absVal = abs(value)
        if (absVal != 0.0 && (absVal >= 1e12 || absVal < 1e-7)) {
            return String.format("%.6e", value)
        }

        val bd = BigDecimal(value).setScale(precision, RoundingMode.HALF_UP).stripTrailingZeros()
        return bd.toPlainString()
    }
}
