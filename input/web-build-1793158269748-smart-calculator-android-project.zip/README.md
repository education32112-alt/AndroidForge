# Smart Calculator — Android Application

**Developed by:** Education With Hassan  
**Package:** `com.educationwithhassan.smartcalculator`  
**Target:** Android 7.0+ (API 24 to API 34)  
**UI Framework:** Jetpack Compose (Material 3)  
**Architecture:** Clean MVVM (UI, ViewModel, Engine, Data)  
**Monetization:** Google Mobile Ads (AdMob pub-3133971041724338)  

---

## Release Signing & Amazon Appstore Submission Guide

### Why Amazon Appstore Rejects "Android Debug" Certificates
When building release APKs without configuring a custom keystore, Android Gradle default configurations used to sign with `debug.keystore`, resulting in certificate:
`CN=Android Debug, O=Android, C=US`

Amazon Appstore, Google Play, Samsung Galaxy Store, and OPPO App Market strictly **reject** apps signed with the Android Debug certificate.

### Fixed Configuration in `app/build.gradle.kts`
The release build type now strictly requires your official release keystore and credentials:
- **No Hardcoded Passwords:** Credentials are read dynamically via environment variables, GitHub Secrets, or local properties.
- **Fail-Fast Safety:** If release credentials are missing, `./gradlew assembleRelease` **fails immediately with a clear error message** rather than silently falling back to the debug certificate.

---

## 1. How to Generate Your Release Keystore (One-Time)

Run this standard command in your terminal (Linux, macOS, or Windows CMD/PowerShell with Java JDK installed):

```bash
keytool -genkeypair -v \
  -keystore smartcalculator-release.jks \
  -alias smartcalculator \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -dname "CN=Education With Hassan, OU=Mobile, O=Education With Hassan, C=US"
```

1. Enter and remember a strong keystore password (e.g. `MySecurePass2026!`).
2. Keep `smartcalculator-release.jks` in a safe, private place. **Never commit it to public GitHub repositories!**

---

## 2. Using GitHub Actions (Automated CI/CD Build)

This project includes a ready-to-use GitHub Actions workflow at `.github/workflows/build-release.yml`.

### Step 1: Convert your keystore to Base64
Run this command in terminal to get the Base64 text:
- **Linux/macOS:**
  ```bash
  base64 -w 0 smartcalculator-release.jks > keystore_base64.txt
  ```
- **Windows PowerShell:**
  ```powershell
  [Convert]::ToBase64String([IO.File]::ReadAllBytes("smartcalculator-release.jks")) | Out-File -Encoding ASCII keystore_base64.txt
  ```

### Step 2: Configure GitHub Repository Secrets
Go to your GitHub repository:
**Settings > Secrets and variables > Actions > New repository secret** and add:

| Secret Name | Description / Value |
|---|---|
| `RELEASE_KEYSTORE_BASE64` | The entire content of `keystore_base64.txt` |
| `KEYSTORE_PASSWORD` | Password you set when creating the keystore |
| `KEY_ALIAS` | Key alias name (e.g. `smartcalculator`) |
| `KEY_PASSWORD` | Password for the key (usually same as keystore password) |

### Step 3: Run the Workflow
1. Go to the **Actions** tab on your GitHub repository.
2. Select **Build & Sign Release APK**.
3. Click **Run workflow**.
4. The workflow will build, sign with your custom release certificate, run `apksigner verify --print-certs` to prove it is not debug-signed, and make the signed APK downloadable under **Artifacts**.

---

## 3. Using AndroidForge

If you build via AndroidForge:
1. In AndroidForge project settings, navigate to **Signing Configuration** / **Keystore Settings**.
2. Upload your `smartcalculator-release.jks` file.
3. Enter:
   - Keystore Password: (your password)
   - Key Alias: `smartcalculator`
   - Key Password: (your key password)
4. Or set the Environment Variables in AndroidForge:
   - `KEYSTORE_FILE`: Path to uploaded keystore (e.g. `release.keystore`)
   - `KEYSTORE_PASSWORD`: Keystore password
   - `KEY_ALIAS`: Key alias
   - `KEY_PASSWORD`: Key password
5. Trigger build `assembleRelease`.

---

## 4. How to Verify Your APK Certificate Before Submitting

Always verify the APK certificate before uploading to Amazon Appstore:

### Method A: Using `apksigner` (Recommended)
```bash
$ANDROID_HOME/build-tools/34.0.0/apksigner verify --verbose --print-certs app-release.apk
```

**Expected output:**
```text
Verifies
Verified using v1 scheme (JAR signing): true
Verified using v2 scheme (APK Signature Scheme v2): true
Number of signers: 1
Signer #1 certificate DN: CN=Education With Hassan, OU=Mobile, O=Education With Hassan, C=US
```
*(Verify that `Signer #1 certificate DN` is **NOT** `CN=Android Debug, O=Android, C=US`)*

### Method B: Using `keytool`
```bash
keytool -printcert -jarfile app-release.apk
```

---

## 5. Local Command Line Build

To build locally with credentials from command line without saving passwords in files:

```bash
KEYSTORE_FILE="/path/to/smartcalculator-release.jks" \
KEYSTORE_PASSWORD="YourPassword" \
KEY_ALIAS="smartcalculator" \
KEY_PASSWORD="YourPassword" \
./gradlew assembleRelease
```

Signed APK output location:
`app/build/outputs/apk/release/app-release.apk`
