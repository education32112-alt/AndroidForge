package com.educationwithhassan.smartcalculator.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.educationwithhassan.smartcalculator.calculator.*
import com.educationwithhassan.smartcalculator.ui.components.*
import com.educationwithhassan.smartcalculator.ui.theme.*
import com.educationwithhassan.smartcalculator.viewmodel.CalculatorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: CalculatorViewModel,
    onNavigateToHistory: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Smart Calculator",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Education With Hassan",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                },
                actions = {
                    // Scientific Mode Toggle Button
                    IconButton(onClick = { viewModel.onAction(CalculatorAction.ToggleScientific) }) {
                        Icon(
                            imageVector = Icons.Default.Science,
                            contentDescription = "Toggle Scientific Mode",
                            tint = if (state.isScientific) CyanAccent else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    // History Button
                    IconButton(onClick = onNavigateToHistory) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Calculation History",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    // Settings Button
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Display Section: Expression, Result, Preview & Status Indicators
            DisplaySection(
                expression = state.expression,
                result = state.result,
                previewResult = state.previewResult,
                errorMessage = state.errorMessage,
                isScientific = state.isScientific,
                angleMode = state.angleMode,
                hasMemory = state.hasMemory,
                onToggleAngleMode = { viewModel.onAction(CalculatorAction.ToggleAngleMode) },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Memory Toolbar
            MemoryBar(
                hasMemory = state.hasMemory,
                onClear = { viewModel.onAction(CalculatorAction.MemoryClear) },
                onRecall = { viewModel.onAction(CalculatorAction.MemoryRecall) },
                onAdd = { viewModel.onAction(CalculatorAction.MemoryAdd) },
                onSubtract = { viewModel.onAction(CalculatorAction.MemorySubtract) },
                onStore = { viewModel.onAction(CalculatorAction.MemoryStore) },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Calculator Keypad
            KeypadSection(
                isScientific = state.isScientific,
                onAction = { viewModel.onAction(it) },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
