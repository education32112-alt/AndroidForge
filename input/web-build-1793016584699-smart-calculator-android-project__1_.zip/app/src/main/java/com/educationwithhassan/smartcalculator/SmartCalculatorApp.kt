package com.educationwithhassan.smartcalculator

import android.app.Application

/**
 * Application class for Smart Calculator.
 * Initializes offline repositories and preferences without network SDKs.
 */
class SmartCalculatorApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
