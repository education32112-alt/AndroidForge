package com.educationwithhassan.smartcalculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.educationwithhassan.smartcalculator.ui.screens.*
import com.educationwithhassan.smartcalculator.ui.theme.SmartCalculatorTheme
import com.educationwithhassan.smartcalculator.viewmodel.CalculatorViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SmartCalculatorTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    val viewModel: CalculatorViewModel = viewModel()

                    NavHost(navController = navController, startDestination = "home") {
                        composable("home") {
                            HomeScreen(
                                viewModel = viewModel,
                                onNavigateToHistory = { navController.navigate("history") },
                                onNavigateToSettings = { navController.navigate("settings") }
                            )
                        }
                        composable("history") {
                            HistoryScreen(
                                viewModel = viewModel,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                        composable("settings") {
                            SettingsScreen(
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateToAbout = { navController.navigate("about") },
                                onNavigateToHelp = { navController.navigate("help") },
                                onNavigateToPrivacy = { navController.navigate("privacy") },
                                viewModel = viewModel
                            )
                        }
                        composable("about") {
                            AboutScreen(onNavigateBack = { navController.popBackStack() })
                        }
                        composable("help") {
                            HelpScreen(onNavigateBack = { navController.popBackStack() })
                        }
                        composable("privacy") {
                            PrivacyScreen(onNavigateBack = { navController.popBackStack() })
                        }
                    }
                }
            }
        }
    }
}
