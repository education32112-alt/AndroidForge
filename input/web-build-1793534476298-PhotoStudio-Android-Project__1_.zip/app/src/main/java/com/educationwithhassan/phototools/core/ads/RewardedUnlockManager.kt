package com.educationwithhassan.phototools.core.ads

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * RewardedUnlockManager
 * Manages unlock states and consumable quotas for all 6 Photo Studio features.
 * Features:
 * 1. Background Cutout (+3 sessions per ad view)
 * 2. Premium Filters Pack (Cinema Gold, Cyberpunk Neon, Vintage Noir, Sunset)
 * 3. Batch Processing (+5 sessions per ad view)
 * 4. 100% Ultra HQ Export (lossless output quality)
 * 5. Pro Effects (Vignette, Dramatic HDR, Tilt Shift)
 * 6. International Passport Templates (Canada, Australia, Schengen)
 */
object RewardedUnlockManager {
    private const val PREFS_NAME = "photo_studio_rewarded_prefs"

    private const val KEY_BG_SESSIONS = "bg_sessions_quota"
    private const val KEY_PREMIUM_FILTERS = "premium_filters_unlocked"
    private const val KEY_BATCH_SESSIONS = "batch_sessions_quota"
    private const val KEY_ULTRA_HQ = "ultra_hq_unlocked"
    private const val KEY_PRO_EFFECTS = "pro_effects_unlocked"
    private const val KEY_PASSPORT_TEMPLATES = "passport_templates_unlocked"

    private lateinit var prefs: SharedPreferences

    private val _bgSessions = MutableStateFlow(3)
    val bgSessions: StateFlow<Int> = _bgSessions.asStateFlow()

    private val _premiumFiltersUnlocked = MutableStateFlow(false)
    val premiumFiltersUnlocked: StateFlow<Boolean> = _premiumFiltersUnlocked.asStateFlow()

    private val _batchSessions = MutableStateFlow(2)
    val batchSessions: StateFlow<Int> = _batchSessions.asStateFlow()

    private val _ultraHqUnlocked = MutableStateFlow(false)
    val ultraHqUnlocked: StateFlow<Boolean> = _ultraHqUnlocked.asStateFlow()

    private val _proEffectsUnlocked = MutableStateFlow(false)
    val proEffectsUnlocked: StateFlow<Boolean> = _proEffectsUnlocked.asStateFlow()

    private val _passportTemplatesUnlocked = MutableStateFlow(false)
    val passportTemplatesUnlocked: StateFlow<Boolean> = _passportTemplatesUnlocked.asStateFlow()

    fun initialize(context: Context) {
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _bgSessions.value = prefs.getInt(KEY_BG_SESSIONS, 3)
        _premiumFiltersUnlocked.value = prefs.getBoolean(KEY_PREMIUM_FILTERS, false)
        _batchSessions.value = prefs.getInt(KEY_BATCH_SESSIONS, 2)
        _ultraHqUnlocked.value = prefs.getBoolean(KEY_ULTRA_HQ, false)
        _proEffectsUnlocked.value = prefs.getBoolean(KEY_PRO_EFFECTS, false)
        _passportTemplatesUnlocked.value = prefs.getBoolean(KEY_PASSPORT_TEMPLATES, false)
    }

    fun addBgSessions(amount: Int = 3) {
        val updated = _bgSessions.value + amount
        _bgSessions.value = updated
        prefs.edit().putInt(KEY_BG_SESSIONS, updated).apply()
    }

    fun consumeBgSession(): Boolean {
        if (_bgSessions.value <= 0) return false
        val updated = _bgSessions.value - 1
        _bgSessions.value = updated
        prefs.edit().putInt(KEY_BG_SESSIONS, updated).apply()
        return true
    }

    fun unlockPremiumFilters() {
        _premiumFiltersUnlocked.value = true
        prefs.edit().putBoolean(KEY_PREMIUM_FILTERS, true).apply()
    }

    fun addBatchSessions(amount: Int = 5) {
        val updated = _batchSessions.value + amount
        _batchSessions.value = updated
        prefs.edit().putInt(KEY_BATCH_SESSIONS, updated).apply()
    }

    fun consumeBatchSession(): Boolean {
        if (_batchSessions.value <= 0) return false
        val updated = _batchSessions.value - 1
        _batchSessions.value = updated
        prefs.edit().putInt(KEY_BATCH_SESSIONS, updated).apply()
        return true
    }

    fun unlockUltraHq() {
        _ultraHqUnlocked.value = true
        prefs.edit().putBoolean(KEY_ULTRA_HQ, true).apply()
    }

    fun unlockProEffects() {
        _proEffectsUnlocked.value = true
        prefs.edit().putBoolean(KEY_PRO_EFFECTS, true).apply()
    }

    fun unlockPassportTemplates() {
        _passportTemplatesUnlocked.value = true
        prefs.edit().putBoolean(KEY_PASSPORT_TEMPLATES, true).apply()
    }
}