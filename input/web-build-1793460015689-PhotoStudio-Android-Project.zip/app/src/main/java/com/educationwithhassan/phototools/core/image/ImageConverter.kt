package com.educationwithhassan.phototools.core.image

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Build
import java.io.ByteArrayOutputStream

object ImageConverter {

    enum class TargetFormat(val displayName: String, val extension: String, val mimeType: String, val supportsTransparency: Boolean) {
        JPG("JPEG (.jpg)", "jpg", "image/jpeg", false),
        PNG("PNG (.png)", "png", "image/png", true),
        WEBP("WebP (.webp)", "webp", "image/webp", true)
    }

    data class ConversionResult(
        val outputBitmap: Bitmap,
        val outputBytes: ByteArray,
        val format: TargetFormat,
        val fileSizeFormatted: String,
        val byteSize: Long
    )

    fun convert(
        source: Bitmap,
        target: TargetFormat,
        quality: Int = 90
    ): ConversionResult {
        // Prepare bitmap. If target is JPG and source has alpha channel, render onto a solid white background
        val bitmapToSave: Bitmap = if (!target.supportsTransparency && source.hasAlpha()) {
            val flattened = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(flattened)
            canvas.drawColor(Color.WHITE)
            canvas.drawBitmap(source, 0f, 0f, null)
            flattened
        } else {
            source
        }

        val stream = ByteArrayOutputStream()
        val compressFormat = when (target) {
            TargetFormat.JPG -> Bitmap.CompressFormat.JPEG
            TargetFormat.PNG -> Bitmap.CompressFormat.PNG
            TargetFormat.WEBP -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    if (quality >= 100) Bitmap.CompressFormat.WEBP_LOSSLESS else Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    @Suppress("DEPRECATION")
                    Bitmap.CompressFormat.WEBP
                }
            }
        }

        bitmapToSave.compress(compressFormat, quality.coerceIn(1, 100), stream)
        val bytes = stream.toByteArray()

        return ConversionResult(
            outputBitmap = bitmapToSave,
            outputBytes = bytes,
            format = target,
            fileSizeFormatted = BitmapUtils.formatFileSize(bytes.size.toLong()),
            byteSize = bytes.size.toLong()
        )
    }
}
