package com.educationwithhassan.phototools.ui.screens

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.educationwithhassan.phototools.core.ads.AdMobManager
import com.educationwithhassan.phototools.core.image.BitmapUtils
import com.educationwithhassan.phototools.core.image.ImageCompressor
import com.educationwithhassan.phototools.core.storage.HistoryRepository
import com.educationwithhassan.phototools.core.storage.MediaStoreSaver
import com.educationwithhassan.phototools.data.model.SavedProject
import com.educationwithhassan.phototools.data.preferences.AppPreferences
import com.educationwithhassan.phototools.ui.PhotoStudioViewModel
import com.educationwithhassan.phototools.ui.components.EmptyPhotoPlaceholder
import com.educationwithhassan.phototools.ui.components.PrimaryActionButton
import com.educationwithhassan.phototools.ui.components.SliderControl
import com.educationwithhassan.phototools.ui.components.ToolTopBar
import com.educationwithhassan.phototools.ui.theme.PrimaryBlue
import com.educationwithhassan.phototools.ui.theme.SuccessGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun CompressorScreen(
    viewModel: PhotoStudioViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val preferences = remember { AppPreferences(context) }
    val historyRepo = remember { HistoryRepository(context) }

    val originalBitmap by viewModel.currentBitmap.collectAsState()
    val originalFileSize by viewModel.fileSize.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var quality by remember { mutableStateOf(preferences.defaultQuality.toFloat()) }
    var selectedFormat by remember { mutableStateOf("WEBP") } // WEBP or JPG

    var isProcessing by remember { mutableStateOf(false) }
    var compressionResult by remember { mutableStateOf<ImageCompressor.CompressionResult?>(null) }
    var lastSavedResult by remember { mutableStateOf<MediaStoreSaver.SaveResult?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.setPhotoUri(uri)
            lastSavedResult = null
        }
    }

    // Recalculate compression when quality, format, or original bitmap changes
    LaunchedEffect(originalBitmap, quality, selectedFormat) {
        val bmp = originalBitmap ?: return@LaunchedEffect
        isProcessing = true
        withContext(Dispatchers.IO) {
            val result = ImageCompressor.compress(
                bitmap = bmp,
                quality = quality.toInt(),
                format = selectedFormat,
                originalSizeBytes = originalFileSize
            )
            withContext(Dispatchers.Main) {
                compressionResult = result
                isProcessing = false
            }
        }
    }

    Scaffold(
        topBar = {
            ToolTopBar(
                title = "Photo Compressor",
                onBack = onBack,
                actions = {
                    IconButton(onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Change Photo", tint = PrimaryBlue)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = PrimaryBlue)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Loading photo...", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            } else if (originalBitmap == null) {
                EmptyPhotoPlaceholder(
                    title = if (errorMessage != null) "Failed to Load Photo" else "No Photo Selected",
                    subtitle = errorMessage ?: "Select a photo from your gallery to compress",
                    onSelectPhoto = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                )
            } else {
                // Image Preview Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        compressionResult?.compressedBitmap?.let { bmp ->
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = "Preview",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(8.dp)
                            )
                        } ?: CircularProgressIndicator(color = PrimaryBlue)

                        // Floating comparison chip
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "Preview (${compressionResult?.format ?: selectedFormat})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // File Size Statistics Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Original Size",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = BitmapUtils.formatFileSize(originalFileSize),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = null,
                            tint = PrimaryBlue
                        )

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Compressed",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = BitmapUtils.formatFileSize(compressionResult?.compressedSize ?: 0L),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = SuccessGreen
                                )
                            )
                            compressionResult?.let { res ->
                                if (res.savingsPercentage > 0) {
                                    Text(
                                        text = "${res.savingsPercentage}% Smaller",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = SuccessGreen
                                    )
                                }
                            }
                        }
                    }
                }

                // Output Format Selection
                Column {
                    Text(
                        text = "Output Format",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listOf("WEBP", "JPG").forEach { fmt ->
                            val isSelected = selectedFormat == fmt
                            OutlinedButton(
                                onClick = { selectedFormat = fmt },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (isSelected) PrimaryBlue.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface,
                                    contentColor = if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.onSurface
                                ),
                                border = ButtonDefaults.outlinedButtonBorder.copy(
                                    brush = androidx.compose.ui.graphics.SolidColor(
                                        if (isSelected) PrimaryBlue else MaterialTheme.colorScheme.outline
                                    )
                                )
                            ) {
                                Text(
                                    text = if (fmt == "WEBP") "WebP (Best Compression)" else "JPG (Universal)",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                )
                            }
                        }
                    }
                }

                // Quality Slider
                SliderControl(
                    title = "Compression Quality",
                    value = quality,
                    onValueChange = { quality = it },
                    valueRange = 10f..100f,
                    valueDisplay = "${quality.toInt()}%"
                )

                // Actions: Save & Share
                PrimaryActionButton(
                    text = if (isProcessing) "Compressing..." else "Save Compressed Image",
                    enabled = !isProcessing && compressionResult != null,
                    onClick = {
                        val result = compressionResult ?: return@PrimaryActionButton
                        coroutineScope.launch {
                            val saveRes = MediaStoreSaver.saveBitmap(
                                context = context,
                                bitmap = result.compressedBitmap,
                                format = selectedFormat,
                                quality = quality.toInt(),
                                prefix = "Compressed"
                            )
                            lastSavedResult = saveRes
                            if (saveRes.success && saveRes.uri != null) {
                                historyRepo.addProject(
                                    SavedProject(
                                        id = saveRes.fileName,
                                        title = "Compressed Photo",
                                        toolType = "Compressor",
                                        uriString = saveRes.uri.toString(),
                                        timestamp = System.currentTimeMillis(),
                                        width = result.compressedBitmap.width,
                                        height = result.compressedBitmap.height,
                                        fileSizeFormatted = saveRes.fileSizeFormatted
                                    )
                                )
                                Toast.makeText(context, "Saved to Pictures/PhotoStudio", Toast.LENGTH_SHORT).show()

                                // Check frequency cap for non-intrusive AdMob interstitial
                                if (preferences.incrementActionAndShouldShowAd()) {
                                    (context as? Activity)?.let { act ->
                                        AdMobManager.showInterstitialIfReady(act) {}
                                    }
                                }
                            }
                        }
                    }
                )

                lastSavedResult?.let { res ->
                    if (res.success && res.uri != null) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.1f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = SuccessGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text("Saved Successfully!", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = SuccessGreen)
                                        Text(res.fileSizeFormatted, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Button(
                                    onClick = { MediaStoreSaver.shareImage(context, res.uri) },
                                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Share", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
