package com.educationwithhassan.phototools.core.image

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import com.educationwithhassan.phototools.data.model.PassportPreset
import kotlin.math.roundToInt

object PassportSheetGenerator {

    val standardPresets = listOf(
        PassportPreset(
            id = "us_passport",
            name = "United States (2x2 in)",
            country = "USA",
            widthMm = 50.8f,
            heightMm = 50.8f,
            targetWidthPx = 600,
            targetHeightPx = 600,
            description = "Official 2x2 inch standard for US Passports, Green Cards, and Visas (300 DPI)."
        ),
        PassportPreset(
            id = "uk_eu_passport",
            name = "UK / Schengen / EU (35x45 mm)",
            country = "United Kingdom & Europe",
            widthMm = 35f,
            heightMm = 45f,
            targetWidthPx = 413,
            targetHeightPx = 531,
            description = "Standard 35x45 mm for UK, European Union Schengen visas and passports."
        ),
        PassportPreset(
            id = "india_passport",
            name = "India Passport (35x45 mm / 51x51 mm)",
            country = "India",
            widthMm = 35f,
            heightMm = 45f,
            targetWidthPx = 413,
            targetHeightPx = 531,
            description = "Standard Indian Passport seva format (35x45 mm)."
        ),
        PassportPreset(
            id = "canada_passport",
            name = "Canada Passport (50x70 mm)",
            country = "Canada",
            widthMm = 50f,
            heightMm = 70f,
            targetWidthPx = 590,
            targetHeightPx = 826,
            description = "Standard 50x70 mm Canadian Passport photo with head size 31-36 mm."
        ),
        PassportPreset(
            id = "square_standard",
            name = "Square 1:1 (50x50 mm)",
            country = "Global",
            widthMm = 50f,
            heightMm = 50f,
            targetWidthPx = 600,
            targetHeightPx = 600,
            description = "Universal square photo for online portals, badges, and company IDs."
        )
    )

    enum class PrintLayout(val label: String, val rows: Int, val cols: Int, val totalCopies: Int) {
        SINGLE("Single Photo", 1, 1, 1),
        TWO_COPIES("2 Copies", 1, 2, 2),
        FOUR_COPIES("4 Copies (2x2)", 2, 2, 4),
        SIX_COPIES("6 Copies (4x6\" Sheet)", 2, 3, 6),
        EIGHT_COPIES("8 Copies (4x6\" Sheet)", 2, 4, 8)
    }

    /**
     * Prepares single passport photo cropped to standard preset ratio, with optional white background
     */
    fun prepareSinglePhoto(
        source: Bitmap,
        preset: PassportPreset,
        applyWhiteBackground: Boolean = true
    ): Bitmap {
        val targetW = preset.targetWidthPx
        val targetH = preset.targetHeightPx

        // Crop center according to preset aspect ratio
        val targetRatio = targetW.toFloat() / targetH.toFloat()
        val cropRect = ImageCropper.getCenteredCropRect(source.width, source.height, targetRatio)
        val cropped = ImageCropper.crop(source, cropRect)

        val scaled = Bitmap.createScaledBitmap(cropped, targetW, targetH, true)

        if (applyWhiteBackground) {
            val flattened = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(flattened)
            canvas.drawColor(Color.WHITE)
            canvas.drawBitmap(scaled, 0f, 0f, null)
            return flattened
        }

        return scaled
    }

    /**
     * Generates a 4x6 inch printable photo sheet (1800x1200 px at 300 DPI) with cutting guides.
     */
    fun generatePrintSheet(
        singlePassportPhoto: Bitmap,
        layout: PrintLayout,
        drawCutLines: Boolean = true
    ): Bitmap {
        if (layout == PrintLayout.SINGLE) {
            return singlePassportPhoto
        }

        // Standard 4x6 inch sheet at 300 DPI is 1800x1200 (landscape) or 1200x1800 (portrait)
        val sheetWidth = 1800
        val sheetHeight = 1200

        val sheetBitmap = Bitmap.createBitmap(sheetWidth, sheetHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(sheetBitmap)
        canvas.drawColor(Color.WHITE)

        val borderPaint = Paint().apply {
            color = Color.parseColor("#CCCCCC")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }

        val totalPhotos = layout.totalCopies
        val cols = layout.cols
        val rows = layout.rows

        // Size each photo on the sheet
        val photoW = (singlePassportPhoto.width * 0.9f).roundToInt()
        val photoH = (singlePassportPhoto.height * 0.9f).roundToInt()
        val scaledUnit = Bitmap.createScaledBitmap(singlePassportPhoto, photoW, photoH, true)

        val availableW = sheetWidth / cols
        val availableH = sheetHeight / rows

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val index = r * cols + c
                if (index >= totalPhotos) break

                val cellLeft = c * availableW
                val cellTop = r * availableH

                val drawX = cellLeft + (availableW - photoW) / 2f
                val drawY = cellTop + (availableH - photoH) / 2f

                canvas.drawBitmap(scaledUnit, drawX, drawY, null)

                if (drawCutLines) {
                    canvas.drawRect(
                        drawX - 1,
                        drawY - 1,
                        drawX + photoW + 1,
                        drawY + photoH + 1,
                        borderPaint
                    )
                }
            }
        }

        return sheetBitmap
    }
}
