package com.educationwithhassan.phototools.data.preferences

import android.content.Context
import android.content.SharedPreferences

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("photo_studio_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_THEME_MODE = "theme_mode" // "system", "light", "dark"
        private const val KEY_DEFAULT_FORMAT = "default_format" // "jpg", "png", "webp"
        private const val KEY_DEFAULT_QUALITY = "default_quality" // 1 - 100
        private const val KEY_ACTION_COUNTER = "action_counter"
    }

    var themeMode: String
        get() = prefs.getString(KEY_THEME_MODE, "system") ?: "system"
        set(value) = prefs.edit().putString(KEY_THEME_MODE, value).apply()

    var defaultFormat: String
        get() = prefs.getString(KEY_DEFAULT_FORMAT, "jpg") ?: "jpg"
        set(value) = prefs.edit().putString(KEY_DEFAULT_FORMAT, value).apply()

    var defaultQuality: Int
        get() = prefs.getInt(KEY_DEFAULT_QUALITY, 85)
        set(value) = prefs.edit().putInt(KEY_DEFAULT_QUALITY, value).apply()

    var actionCounter: Int
        get() = prefs.getInt(KEY_ACTION_COUNTER, 0)
        set(value) = prefs.edit().putInt(KEY_ACTION_COUNTER, value).apply()

    fun incrementActionAndShouldShowAd(threshold: Int = 3): Boolean {
        val current = actionCounter + 1
        return if (current >= threshold) {
            actionCounter = 0
            true
        } else {
            actionCounter = current
            false
        }
    }
}
