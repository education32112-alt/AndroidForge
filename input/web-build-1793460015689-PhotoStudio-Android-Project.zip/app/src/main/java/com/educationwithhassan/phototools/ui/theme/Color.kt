package com.educationwithhassan.phototools.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF2563EB)
val PrimaryDark = Color(0xFF1D4ED8)
val PrimaryLight = Color(0xFF60A5FA)
val SecondaryTeal = Color(0xFF0D9488)
val AccentAmber = Color(0xFFF59E0B)

// Dark Theme Colors
val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkBorder = Color(0xFF334155)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)
val LightBorder = Color(0xFFE2E8F0)

val SuccessGreen = Color(0xFF10B981)
val DangerRed = Color(0xFFEF4444)
