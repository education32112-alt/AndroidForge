# Photo Studio – Photo Tools (Native Android)
**Package:** `com.educationwithhassan.phototools`  
**Developer:** Rana Hassan  
**Framework:** Native Android with Kotlin & Jetpack Compose (Material 3)  
**Target Market:** USA & Worldwide  

---

## 📸 Key Features & Architecture

1. **100% Offline Core Processing**
   - Zero remote server uploads or network dependencies for image manipulation.
   - Built with high-performance coroutines on `Dispatchers.IO` to prevent UI stalls.

2. **Full Photo Utility Suite**
   - **Photo Compressor**: Multi-format (WebP lossy/lossless, JPG) compression with real-time byte savings calculations.
   - **Photo Resizer**: Custom dimension scaling, aspect-ratio lock, and industry presets (Full HD, 720p, Instagram Square, Story, YouTube).
   - **Image Cropper**: Aspect ratios (Free, 1:1, 4:3, 16:9, 3:4) with rotation and flipping.
   - **Format Converter**: Lossless/lossy transcode between JPG, PNG, and WebP with transparency support and clean white flattening.
   - **Photo Editor**: Hardware-accelerated ColorMatrix filters for Brightness, Contrast, Saturation, Exposure, Warmth, Sharpness, B&W, Sepia, and Vintage tone curves. Includes live Before/After comparison and Undo/Redo stack.
   - **Image Rotator**: 90°, 180°, 270° lossless matrix rotations with horizontal & vertical mirroring.
   - **Background Blur**: Multi-pass stack blur with radial depth-of-field focal masks.
   - **Passport Photo Maker**: Presets for US (2x2"), UK/EU (35x45mm), India, and multi-copy print sheets (2x2, 2x3, 4x6" grid) with cutting lines and pure white background flattening.
   - **Background Remover**: Offline solid-color/luminance cutout engine alongside transparent notification for future on-device ML segmentation.

3. **Android Storage & Privacy**
   - Saves directly to `Pictures/PhotoStudio/` via modern scoped storage `MediaStore.Images.Media`.
   - Never overwrites original images.
   - Integrated Android Share Sheet via FileProvider.

4. **Monetization & AdMob Integration**
   - Google Mobile Ads SDK `com.google.android.gms:play-services-ads:23.3.0`.
   - Pre-configured with official Google test Ad Unit IDs.
   - Frequency-capped interstitial ads (triggered only after 3 completed user workflows, never during active editing or saving).
   - Non-intrusive bottom banner reserved on home/dashboard.

---

## 🚀 How to Build and Run in Android Studio

### Prerequisites
- Android Studio Ladybug / Koala / Iguana or newer
- JDK 17 or higher
- Android SDK Platform 35 (Android 15)

### Steps
1. Unzip `PhotoStudio-Android-Project.zip`.
2. Open Android Studio -> **File** -> **Open** -> select the unzipped `android/` directory.
3. Allow Gradle to sync dependencies automatically.
4. Run on a physical device or emulator with API 26 or higher:
   ```bash
   ./gradlew assembleDebug
   ```
5. To generate a signed release APK:
   ```bash
   ./gradlew assembleRelease
   ```

---

## ⚙️ Configuring Production AdMob IDs
In `app/src/main/res/values/strings.xml`, replace the test IDs with your approved AdMob IDs before publishing to Google Play:
```xml
<string name="admob_app_id">YOUR_ADMOB_APP_ID</string>
<string name="admob_banner_home">YOUR_ADMOB_BANNER_UNIT_ID</string>
<string name="admob_interstitial_tool">YOUR_ADMOB_INTERSTITIAL_UNIT_ID</string>
```
